<?php
 class Main_model extends CI_Model{
	public function __construct(){
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
	}
	
	public function database_connect(){
		if( $this->db->get('45cms_posts')){
			return true;
		}else{
			echo 'Unable to connect!';exit;
			return false;
		}
	}
	
	//20170209
	//First parameter is the purpose. 2nd is the team's creator id, 3rd is the team's id, 4th is the current users id.
	/*$purpose variable
		0 = add new relation record or add a new request to join record
		1 = get or view relation/ relations
		2 = update the relation status
		3 = delete a relation status
		
		For $purpose 0
			This function returns an array variable to the controller with a result boolean variable in it 
			which determines if a certain request was a success if true or a failure if false.
		For $purpose 1
			Returns a set of records to the controller.
	*/
	public function team_relations($purpose, $team_creator_id = FALSE, $team_id = FALSE, $current_user_id = FALSE){
		switch($purpose){
			case 0:	//The user wants to add a new request record into the table.
				//Check if this user already has a relation record with this team.
				$duplicates = $this->check_relation_duplicate($team_id, $current_user_id);
				if($duplicates > 0){
					//This user already have a relation record with this team.
					//So the user is not able to add another record to the table.
					$result['system_message'] = 'Already made a request or already joined team.';
					$result['result'] = FALSE;
				}else{
					//There was no existing team and user record found in the database.
					//Continue adding the new request record into the table.
					$data = array(
						'team_id'			=> $team_id,
						'team_creator_id'	=> $team_creator_id,
						'join_requestor_id'	=> $current_user_id,
						'status'			=> FALSE, //Request to join the team is still pending. Waiting acceptance from the creator of the team.
					);
					$this->db->insert('team_relations', $data);
					$result['system_message'] = 'Success: Request to join team successful.';
					$result['result'] = TRUE;
				}
				break;
			case 1: //get or view relation/ relations
				$this->db->where('team_id', $team_id);
				$this->db->where('team_creator_id', $current_user_id);
				$this->db->join('45cms_users', '45cms_users.id = team_relations.join_requestor_id');
				$query = $this->db->get('team_relations');
				$result['records'] = $query->result_array();
				break;
			case 2: //update the relation status
				$join_requestor_id = $current_user_id;
				$this->db->set('status', 1);
				$this->db->where('join_requestor_id', $join_requestor_id);
				$this->db->where('team_id', $team_id);
				if($this->db->update('team_relations')){
					$result['system_message'] = 'User status updated.';
					$result['result'] = TRUE;
				}else{
					$result['system_message'] = 'Failed to update user status.';
					$result['result'] = FALSE;
				}
				break;
		}
		
		return $result;
	}
	
	//check if a user and a team already has an existing record in the team_relations table
	//returns the number of records found
	public function check_relation_duplicate($team_id, $user_id){
		$this->db->where('team_id', $team_id);
		$this->db->where('join_requestor_id', $user_id);
		$this->db->from('team_relations');
		
		$result = $this->db->count_all_results();
		return $result;
	}
	
	//20170203 add new team
	public function add_team($new_team_name){
		$image = FALSE;
		$post_title = $new_team_name;
		$post_content = $new_team_name;
		$post_labels = 'type_team';
		$post_type = 'Normal';
		$url = url_title($post_title, 'underscore', TRUE).'_'.$this->get_unique_number();
		$author_id = $this->session->userdata('user_id');
		$author_name = $this->session->userdata('username');
		
		$duplicate = $this->check_duplicate($url, '45cms_posts', 'url');
		if($duplicate > 0){
			echo 'Title Already Exist!';
			return FALSE;
		}
		
		$data = array(
			'url'		=> $url,
			'title'		=> $post_title,
			'type'		=> $post_type,
			'content'	=> $post_content,
			'image_url'	=> $image,
			'labels'	=> $post_labels,
			'author_id' => $author_id,
			'author'	=> $author_name,
		);
		$this->db->insert('45cms_posts', $data);
		
		//add this team and this user into the team relations table
		$data = $this->get_post($url);
		$team_id = $data['id'];
		$team_creator_id = $author_id;
		$current_user_id = $author_id;
		
		$data = array(
			'team_id'			=> $team_id,
			'team_creator_id'	=> $team_creator_id,
			'join_requestor_id'	=> $current_user_id,
			'status'			=> TRUE,
		);
		$this->db->insert('team_relations', $data);
					
		$result['result'] = TRUE;
		return $result;
	}
	
	//20170201 add new unit
	public function add_unit($new_unit_name, $new_unit_department){
		$image = false;
		$post_title = $new_unit_name;
		$post_content = $new_unit_name;
		$post_labels = 'type_unit, department_'.$new_unit_department;
		$post_type = 'Normal';
		$url = url_title($post_title, 'underscore', TRUE).'_'.$this->get_unique_number();
		$author_id = $this->session->userdata('user_id');
		$author_name = $this->session->userdata('username');
		
		//get the current_team_id from the sessions variable
		$team_id = $this->session->userdata('current_team_id');
		
		$duplicate = $this->check_duplicate($url, '45cms_posts', 'url');
		if($duplicate > 0){
			echo 'Title Already Exist!';
			return FALSE;
		}
		
		$data = array(
			'url'		=> $url,
			'title'		=> $post_title,
			'type'		=> $post_type,
			'content'	=> $post_content,
			'image_url'	=> $image,
			'labels'	=> $post_labels,
			'author_id' => $author_id,
			'author'	=> $author_name,
			'team_id'	=> $team_id,
		);
		$this->db->insert('45cms_posts', $data);
		
		$result['result'] = TRUE;
		return $result;
	}
	
	//20170201 add new task
	public function add_task($new_task_name, $new_task_department){
		$image = false;
		$post_title = $new_task_name;
		$post_content = $new_task_department;
		$post_labels = 'type_task, department_'.$new_task_department;
		$post_type = 'Normal';
		$url = url_title($post_title, 'underscore', TRUE).'_'.$this->get_unique_number();
		$author_id = $this->session->userdata('user_id');
		$author_name = $this->session->userdata('username');
		
		//get the current_team_id from the sessions variable
		$team_id = $this->session->userdata('current_team_id');
		
		$duplicate = $this->check_duplicate($url, '45cms_posts', 'url');
		if($duplicate > 0){
			echo 'Title Already Exist!';
			return FALSE;
		}
		
		$data = array(
			'url'		=> $url,
			'title'		=> $post_title,
			'type'		=> $post_type,
			'content'	=> $post_content,
			'image_url'	=> $image,
			'labels'	=> $post_labels,
			'author_id' => $author_id,
			'author'	=> $author_name,
			'team_id'	=> $team_id,
		);
		$this->db->insert('45cms_posts', $data);
		
		$result['result'] = TRUE;
		return $result;
	}
	
	//20161002
	//Updates the filed 'status' of a record based on the $generated_task_id and $update_type variable values.
	//Returns true or false into the controller.
	public function update_generated_task_status($generated_task_id, $update_type){
		$current_username = $this->session->userdata('username');
		$update_type = ucfirst($update_type);
		//check if this generated_task_id exists in the database
		//send a query to the database to check if this task_id exists in the table
        $query = $this->db->get_where('pmj_generated_tasks', array(
            'generated_task_id' => $generated_task_id
        ));
		//count the number of results found
        $count = $query->num_rows();
		//check how many results were found
		if($count === 0){
		//if nothing was found
			return false;
		}else{
		//if such an id exists on the database
		//proceed with the updating
			$this->db->set('task_status', '"'.$update_type.'"', FALSE);
			$this->db->set('updater_username', '"'.$current_username.'"', FALSE);
			$this->db->where('generated_task_id', $generated_task_id);
			if($this->db->update('pmj_generated_tasks')){
				return true;
			}
			return false;
		}
	}
	
	/*
		Generate tasks for the passed url.
		Returns generated results.
	*/
	public function generate_tasks($url){
		//get $task_id based on the passed $url variable
		$task_values = $this->get_post($url);
		$task_id = $task_values['id'];
		
		//Check if this task has already been generated by checking if 
		//it exists on the pmj_generated_tasks table.
		$records = $this->check_duplicate($task_id, 'pmj_generated_tasks', 'task_id');
		if($records > 0){
			//if this task already have records in the pmj_generated_tasks table
			$result['system_message'] = 'Warning: Tasks already generated.';
			$result['result'] = FALSE;
			return $result;
		}
		
		//get the current_team_id value entered by the user from the sessions variable
		$current_team_id = $this->session->userdata('current_team_id');
		//if the current team is undefined do not proceed
		//only users who are logged in a team can generate tasks
		if((!$current_team_id) || ($current_team_id == '') || ($current_team_id == NULL)){
			echo 'Can not generate tasks when not in a team.';
			$result['result'] = FALSE;
			return $result;
		}
		
		//get $task_department
		$task_department = $task_values['labels'];
		//remove spaces
		$task_department = preg_replace('/\s+/', '', $task_department);
		//split string from comma and save to array
		$task_department_array = explode(',', $task_department);
		//loop through the array to find the department
		foreach($task_department_array as $string){
			//check if the current variable contains the string 'department_'
			if(strpos($string, 'department_') === false){
			//if not, do nothing
			}else{
			//if the variable contains the string 'deparment_'
				//save the variable to the $task_department variable
				$task_department = $string;
			}
		}
		
		//now get the units that belongs to the value of the $task_department variable
		//only get units that belong to the tasks team
		//so get the tasks team id from the sessions variable
		$current_team_id = $this->session->userdata('current_team_id');
		$units = $this->get_units($task_department, $current_team_id);
		$total_units = count($units);
		//check if there were units found
		if($total_units <= 0){
			//if no units where found
			$result['system_message'] = 'Failed: No units found.';
			$result['result'] = false;
		}else{
			//start generating tasks by adding values to the pmj_generated_tasks table
			$units_counter = 0;
			foreach($units as $unit){
				$data[$units_counter] = array(
					'task_id' 			=> $task_id,
					'unit_id' 			=> $units[$units_counter]['id'],
					'date_generated'	=> date("Y-m-d-h-m-s"),
					'date_updated'		=> date("Y-m-d-h-m-s"),
					'team_id'			=> $current_team_id,
					'task_id_unit_id'	=> $task_id.$units[$units_counter]['id'],
				);
				$units_counter++;
			}
			if($this->db->insert_batch('pmj_generated_tasks', $data)){
			//if the insertion of the generated tasks was successful
				//prepare the result array that will be returned to the controller
				$result['result'] = true;
				$result['generated_tasks_id'] = $task_id;
			}else{
				$result['system_message'] = 'Failed: There was an error.';
				$result['result'] = false;
			}
		}
		
		//return result to the controller
		return $result;
	}
	
	/*
		20160904
		$type
			tasks_id - returns a set of records
			task_id - returns single record
		$value
			id of the record
	*/
	public function get_generated_tasks($type, $value){
		switch($type){
			case "tasks_id":
				$this->db->where('task_id', $value);
				$this->db->from('pmj_generated_tasks');
				$this->db->join('45cms_posts', 'pmj_generated_tasks.unit_id = 45cms_posts.id');
				break;
			case "task_id":
				$this->db->where('generated_task_id', $value);
				$this->db->from('pmj_generated_tasks');
				$this->db->join('45cms_posts', 'pmj_generated_tasks.unit_id = 45cms_posts.id');
				break;
		}
		$this->db->order_by('generated_task_id', 'DESC');
		$query = $this->db->get();
		return $query->result_array();
	}
	
	/*
		20160903
		Gets units based on department and team.
	*/
	public function get_units($department, $team_id){
		$this->db->where("`labels` LIKE '%type_unit%' AND `labels` LIKE '%".$department."'");
		$this->db->where('team_id', $team_id);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get('45cms_posts');
		return $query->result_array();
	}
	
	/*20160903*/
	public function get_tasks_or_units($labels){
		$this->db->like('labels', $labels);
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get('45cms_posts');
		return $query->result_array();
	}
	
	//20170204
	public function get_team_tasks_or_units($labels, $team_id, $to_get = false){
		if($to_get != 'type_task'){
			$this->db->where("`labels` LIKE '%".$labels."%' AND `team_id` = '".$team_id."'");
			$this->db->order_by('id', 'DESC');
			$query = $this->db->get('45cms_posts');
			return $query->result_array();
		}else{
			//get the task_id of the 
			$this->db->select("title, labels, id, url, count('task_id') as `total_tasks`, 
				sum(case when task_status = 'Pending' then 1 else 0 end) as `total_pending`,
				sum(case when task_status = 'Completed' then 1 else 0 end) as `total_completed`");
			$this->db->from('45cms_posts');
			$this->db->where("`45cms_posts.labels` LIKE '%".$labels."%' AND `45cms_posts`.`team_id` = '".$team_id."'");
			$this->db->join('pmj_generated_tasks', '45cms_posts.id = pmj_generated_tasks.task_id', 'left');
			$this->db->group_by('id'); 
			$this->db->order_by('id', 'DESC');
			$query = $this->db->get();
			return $query->result_array();
		}
	}
	
	//20170204
	public function check_user_team_status($current_user_id, $team_id){
		$this->db->where('team_id', $team_id);
		$this->db->where('join_requestor_id', $current_user_id);
		$query = $this->db->get('team_relations');
		$rows = $query->result_array();
		foreach($rows as $row){
			if($row['status'] == TRUE){
				$result['system_message'] = 'Success: Allowed to enter team.';
				$result['result'] = TRUE;
			}else{
				$result['system_message'] = 'Failed: Not allowed to enter team.';
				$result['result'] = FALSE;
			}
		}
		return $result;
	}
	
	/*
		20151128
		This function will receive POST method input data from
		the browser. Receive data, clean and process it, then 
		send it back to the Controller to be processed for 
		the View.
		The controller function will then generate a View page
		using the values processed in this function.
	*/
	public function preview_post(){
		// Store input values to variables.
		// Save values into the database as draft post.
		// Return the saved values data to Controller
		// to be displayed by the View.
		
	}
	
	public function get_style($appearance_name){
		$this->db->where('appearance_name', $appearance_name);
		$query = $this->db->get('45cms_appearance');
		return $query->row_array();
	}
	
	public function save_appearance_settings(){
		//save default appearance values to 45cms_appearance table
		$data = array(
			'body_font_family'			=> $this->input->post('body_font_family'),
			'body_font_size'			=> $this->input->post('body_font_size'),
			'body_background_color'		=> $this->input->post('body_background_color'),
			'body_maximum_width'		=> $this->input->post('body_maximum_width'),
			'header_background_color'	=> $this->input->post('header_background_color'),
			'header_header_text_color'	=> $this->input->post('header_header_text_color'),
			'header_normal_text_color'	=> $this->input->post('header_normal_text_color'),
			'header_link_text_color'	=> $this->input->post('header_link_text_color'),
			'article_background_color'	=> $this->input->post('article_background_color'),
			'article_header_text_color'	=> $this->input->post('article_header_text_color'),
			'article_normal_text_color'	=> $this->input->post('article_normal_text_color'),
			'article_link_text_color'	=> $this->input->post('article_link_text_color'),
			'footer_background_color'	=> $this->input->post('footer_background_color'),
			'footer_header_text_color'	=> $this->input->post('footer_header_text_color'),
			'footer_normal_text_color'	=> $this->input->post('footer_normal_text_color'),
			'footer_link_text_color'	=> $this->input->post('footer_link_text_color')
		);
		$this->db->where('appearance_name', 'default');
		$update = $this->db->update('45cms_appearance', $data);
		
		if($update){
			return true;
		}
		return false;
	}
	
	public function password_update_process($current_password, $new_password){
		//check if this current password belongs to the current user_error
		//unlikely if any user can update anyones password, so check
		$current_username = $this->session->userdata('username');
		$current_password = md5($current_password);
		
		$this->db->where('username', $current_username);
		$this->db->where('password', $current_password);
		$query = $this->db->get('45cms_users');
		
		if($query->num_rows() == 1){
			//if this current_password belongs to this current user,
			//continue the password_update process
				$data = array(
					'password' => md5($new_password)
				);
				$this->db->where('username', $current_username);
				$this->db->where('password', $current_password);
				$update = $this->db->update('45cms_users', $data);
				
				if($update){
					$result['status'] = "success";
					$result['message'] = "Success: Password updated successfully.";
					
					return $result;
				}else{
					$result['status'] = "failed";
					$result['message'] = "Error: Update wasn't successful.";
					
					return $result;
				}
		}else{
			//if not return an incorrect password message
			$result['status'] = "failed";
			$result['message'] = "Error: Password Incorrect";
			
			return $result;
		}
	}
	
	public function get_portfolio($quantity = false){
		
	}
	
	/*
		20151112
		Added the add +1 to views value when viewed or each time the 
		url is requested to the browser.
	*/
	public function get_post($url = false){
		if($url === FALSE){
			$this->db->order_by('id', 'DESC');
			$query = $this->db->get('45cms_posts');
			return $query->result_array();
		}
		
		if($this->check_duplicate($url, '45cms_posts', 'url') == 0){
			return False;
		}
	
		$query = $this->db->get_where('45cms_posts', array('url' => $url));
		
		$row = $query->row_array();
		$this->views_plus_one($row['url'], $row['views']);
		
		return $query->row_array();
	}
	
	/*
		20151112
		Add +1 view to the specific url's views value.
	*/
	public function views_plus_one($url, $views){
		$this->update_one_field('url', $url, 'views', ($views + 1));
		return;
	}
	
	public function get_where($field, $value, $limit = false){
		$this->db->like($field, $value);
		//$this->db->where($field, $value);
		$this->db->order_by('id', 'DESC');
		if($limit === false){
			$query = $this->db->get('45cms_posts');
		}else{
			$query = $this->db->get('45cms_posts', $limit);
		}
		return $query->result_array();
	}
	
	/*
		20151112
		Reusable function that would be used in getting database records
		using where, order by, and limit query functionalities.
		
		Returns the query result array.
	*/
	public function get_where_order_by($where_field, $where_field_value, $limit = false, $order_by_field, $order_by_value){
		//var_dump($order_by_field.$order_by_value);exit;
		$this->db->like($where_field, $where_field_value);
		$this->db->order_by($order_by_field, $order_by_value);
		if($limit === false){
			$query = $this->db->get('45cms_posts');
		}else{
			$query = $this->db->get('45cms_posts', $limit);
		}
		return $query->result_array();
	}
	
	public function get_unique_number(){
		return $this->db->count_all('45cms_posts');
	}
	
	public function create($image = False){
		$post_title = $this->input->post('post_title');
		$post_content = $this->input->post('post_content');
		$post_labels = $this->input->post('post_labels');
		$post_type = $this->input->post('post_type');
		$url = url_title($post_title, 'underscore', TRUE).'_'.$this->get_unique_number();
		$author_id = $this->session->userdata('user_id');
		$author_name = $this->session->userdata('username');
		
		$duplicate = $this->check_duplicate($url, '45cms_posts', 'url');
		if($duplicate > 0){
			echo 'Title Already Exist!';
			return FALSE;
		}
		
		$data = array(
			'url'	=> $url,
			'title'	=> $post_title,
			'type'	=> $post_type,
			'content'	=> $post_content,
			'image_url'			=> $image,
			'labels'	=> $post_labels,
			'author_id' => $author_id,
			'author'	=> $author_name,
		);
		$this->db->insert('45cms_posts', $data);
		
		return $url;
	}
	
	//20170202
	//delete user
	public function delete_user($user_id){
		//check if this user does exist in the database
		$query = $this->db->get_where('45cms_users', array('id' => $user_id));
		if($query->num_rows() > 0){
			//if the user exists
			//delete it's record
			$this->db->delete('45cms_users', array('id' => $user_id));
			$result['result'] = TRUE;
		}else{
			$result['result'] = FALSE;
		}
		return $result;
	}
	
	//20170202
	//get user detail
	public function get_user_detail($field = FALSE){
		//check if the user is logged in
		if(!$this->session->userdata('user_validated')){
			//if the user is not logged in
			$result['result'] = FALSE;
		}else{
			//if the user is logged in
			//save the users id into a variable
			$user_id = $this->session->userdata('user_id');
			
			//get the database record using the user_id
			$query = $this->db->get_where('45cms_users', array('id' => $user_id));
			$row = $query->row_array();
			$field_requested = $row[$field];
			
			$result['result'] = TRUE;
			$result[$field] = $field_requested;
		}
		
		return $result;
	}
	
	public function delete($url){
		//delete photo
		$query = $this->db->get_where('45cms_posts', array('url' => $url));
		$row = $query->row_array(); 
		$id = $row['id'];
		$creator_id = $row['author_id'];
		$labels = $row['labels'];
		$team_id = $row['team_id'];
		
		//To know what type of record is being deleted.(ex. team, unit, or task)
		//Check the labels variable, using strpos, if it contains any of the following labels(type_team, type_unit, type_task).
		//Then create a variable that determines what type of data is being deleted.
		//assign as value the numbers 0 for team, 1 for unit, 2 for task, else assign 3.
		if(strpos($labels, 'type_team') !== FALSE){
			//the record is a type_team type
			//if the record is a team set the team_id variable to the id of the team
			$team_id = $id;
			$record_type = 0;
		}elseif(strpos($labels, 'type_unit') !== FALSE){
			//the record is a type_unit type
			$record_type = 1;
		}elseif(strpos($labels, 'type_task') !== FALSE){
			//the record is a type_task
			$record_type = 2;
		}else{
			//the record is not a team, unit, or task type
			$record_type = 3;
		}
		
		//201702040213
		//if the user type of the user who is requesting of the record to be deleted
		//do not bother check who created the record and proceed with the deletion.
			//Get the user type of the current user from the session variables and save
			//it into a variable.
			$current_user_user_type = $this->session->userdata('user_type');
			
			//Check if the user's user_type is 'admin'.
			if($current_user_user_type != 'admin'){
				//If the user type is not admin check if the user is the creator or author of the record.
			
				//20170204
				//check if the current user who is requesting to delete the record is the creator
				//or author of the record
				//====START===
					//get the current user_id in the session and save it into a variable
					$current_user_id = $this->session->userdata('user_id');
					//check if the current users id matches that of the records author_id
					if($creator_id != $current_user_id){
						//if it did not match
						//meaning the current user is not the creator or the author of the record, return FALSE.
						//echo ' Record is not yours to delete.';
						
						return FALSE;
					}
				//====END===
			}
		
		if ($query->num_rows() > 0)
		{
			$row = $query->row_array(); 
			$file = $row['image_url'];
			if($file){
				$path = 'images/uploads/'.$file;
				unlink($path);
			}
		}

		//delete database records
		$this->db->delete('45cms_posts', array('url' => $url));
		
		//if the record type of the deleted variable is a unit, delete ist related generated tasks
		if($record_type == 1){
			$this->db->delete('pmj_generated_tasks', array('unit_id' => $id));
		}
		
		//if the record type of the deleted variable is a task, delete its related generated tasks
		if($record_type == 2){
			$this->db->delete('pmj_generated_tasks', array('task_id' => $id));
		}
		
		//if the record type of the deleted variable is a team, delete all tasks and units related to it
		if($record_type == 0){
			//make sure not to delete teams that has 0 team_id
			$this->db->where('team_id !=', 0);
			//make sure to only delete records that belong to the current deleted team
			$this->db->where('team_id', $team_id);
			$this->db->delete('45cms_posts');
			
			//now delete the generated tasks that are under the deleted team
			//or is bearing the deleted team's id in its team_id field
			$this->db->delete('pmj_generated_tasks', array('team_id' => $team_id));
		}
		return TRUE;
	}
	
	public function update_one_field($filter_field, $filter_field_value, $field, $new_value){
		//echo $field.$value;exit;
		$data = array(
			$field => $new_value
		);
		$this->db->where($filter_field, $filter_field_value);
		$this->db->update('45cms_posts', $data);
	}
	
	public function update_post(){
		$post_url = $this->input->post('post_url');
		$new_title = $this->input->post('post_title');
		$new_content = $this->input->post('post_content');
		$new_labels = $this->input->post('post_labels');
		$post_type = $this->input->post('post_type');
		
		$data = array(
			'title' => $new_title,
			'content' => $new_content,
			'labels' => $new_labels,
			'type' => $post_type,
		);
		$this->db->where('url', $post_url);
		$this->db->update('45cms_posts', $data);
		
		return TRUE;
	}
	
	public function delete_image($filename){
		$this->update_one_field('image_url', $filename, 'image_url', '');
		
		$file = $filename;
		$path = 'images/uploads/'.$file;
		unlink($path);
		
		$message = "<success id='delete_result' name='success'>File Deleted!</success>";
		return $message;
	}
	
	public function register($angular_variables = false){
		if($angular_variables == FALSE){
			$name = $this->input->post('name');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$email = $this->input->post('email');
		}else{
			$name = $angular_variables->new_name;
			$email = $angular_variables->new_email;
			$username = $angular_variables->new_username;
			$password = $angular_variables->new_password;
		}
		
		if($this->check_duplicate($username, '45cms_users', 'username') > 0){
			$result['result'] = FALSE;
			$result['message'] = 'Username already exist.';
			return $result;
		}
		
		$data = array(
			'name' => $name,
			'username' => $username,
			'password' => md5($password),
			'email' => $email
		);
		if($this->db->insert('45cms_users', $data)){
			$result['result'] = TRUE;
			$result['message'] = "You can now login. <input type='text' id='success_signal' value='success' hidden/>";
			return $result;
		}else{
			$result['result'] = FALSE;
			$result['message'] = "Failed to register.<input type='text' id='success_signal' value='failed' hidden/>";
			return $result;
		}
	}
	
	//20151228 Returns the value of the specified setting_name from the 45cms_settings table.
	public function get_setting_value($setting_name){
		$this->db->where('setting_name', $setting_name);
		$query = $this->db->get('45cms_settings');
		$row = $query->row_array();
		if($row['setting_value'] == ''){
			echo "ERROR: ".$setting_name." not specified.";
			return "Unspecified.";
		}else{
			return $row['setting_value'];
		}
	}
	
	//20151228 Returns all the value inside the 45cms_settings table.
	public function get_settings(){
		$query = $this->db->get('45cms_settings');
		return $query->result_array();
	}
	
	public function get_users(){
		$this->db->where('user_type !=','admin');
		$query = $this->db->get('45cms_users');
		return $query->result_array();
	}
	
	//20170115 update
	//returns true or false if the username and password are valid
	public function login($username = FALSE, $password = FALSE){
		if($username == FALSE && $password == FALSE){		
			$username = $this->input->post('username');
			$password = $this->input->post('password');
		}
		$password = md5($password);
		
		$this->db->where('password', $password);
		$this->db->where('username', $username);
		$query = $this->db->get('45cms_users');
		
		if($query->num_rows() == 1)
		{
			$data = array(
				'user_id'			=> $query->row()->id,
				'user_type'			=> $query->row()->user_type,
				'username'			=> $query->row()->username,
				'user_validated'	=> TRUE
			);
			$this->session->set_userdata($data);
			
			$result['result'] = TRUE;
			return $result; //username and password confirmed
		}
		
		$result['result'] = FALSE;
		return $result;
	}
	
	public function check_duplicate($value, $table, $field){
		$this->db->where($field, $value);
		$this->db->from($table);
		
		$result = $this->db->count_all_results();
		return $result;
	}
}