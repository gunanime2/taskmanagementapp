<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/
$route['angular/angular_approve_team_join_request/(:any)/(:any)'] = 'pmj_controller/angular_approve_team_join_request/$1/$2';
$route['angular/angular_get_team_relations/(:any)'] = 'pmj_controller/angular_get_team_relations/$1';
$route['angular/request_join_team/(:any)/(:any)'] = 'pmj_controller/angular_request_join_team/$1/$2';
$route['angular/leave_team'] = 'pmj_controller/angular_leave_team';
$route['angular/get_current_details'] = 'pmj_controller/angular_get_current_details';
$route['angular/enter_team/(:any)/(:any)'] = 'pmj_controller/angular_enter_team/$1/$2';
$route['angular/add_team'] = 'pmj_controller/angular_add_team';
$route['angular/delete_team/(:any)'] = 'main_controller/delete/$1';
$route['angular/get/user/(:any)'] = 'pmj_controller/angular_get_user_detail/$1';
$route['angular/delete_user/(:any)'] = 'pmj_controller/angular_delete_user/$1';
$route['angular/add_user'] = 'pmj_controller/angular_add_user';
$route['angular/get/users'] = 'pmj_controller/angular_get_users';
$route['angular/delete_task/(:any)'] = 'main_controller/delete/$1';
$route['angular/add_task'] = 'pmj_controller/angular_add_task';
$route['angular/delete_unit/(:any)'] = 'main_controller/delete/$1';
$route['angular/add_unit'] = 'pmj_controller/angular_add_unit';
$route['angular/update_task_status/(:any)/(:any)'] = 'pmj_controller/update_task_status/$1/$2';
$route['angular/get/task/(:any)'] = 'pmj_controller/angular_get_generated_tasks/$1';
$route['angular/get/(:any)'] = 'pmj_controller/angular_get/$1';
$route['angular/register_attempt'] = 'public_controller/angular_register_attempt';
$route['angular/login_attempt'] = 'public_controller/angular_login_attempt';
$route['angular/angular_dashboard'] = 'public_controller/angular_index';

$route['admin/update-task-status'] = 'pmj_controller/update_task_status';

$route['view_generated_tasks/(:any)'] = 'pmj_controller/view_generated_tasks/$1';
$route['confirm_generate/(:any)'] = 'pmj_controller/confirm_generate/$1';
$route['process_generate/(:any)'] = 'pmj_controller/process_generate/$1';
$route['view_tasks'] = 'pmj_controller/view_tasks';
$route['view_units'] = 'pmj_controller/view_units';

$route['css/generated_css'] = 'public_controller/generated_css';
$route['admin/parse/(:any)'] = 'main_controller/universal_parser/$1';

$route['admin/modify_appearance'] = 'main_controller/modify_appearance';
$route['create/process_create/upload_image'] = 'main_controller/upload_image';
$route['create/process_create/upload_text_inputs'] = 'main_controller/upload_text_inputs';

$route['portfolio'] = 'public_controller/portfolio';

$route['admin/password_update'] = 'main_controller/password_update';
$route['admin/password_update_process'] = 'main_controller/password_update_process';

$route['process_register'] = 'public_controller/process_register';
$route['register'] = 'public_controller/register';
$route['login'] = 'public_controller/angular_index';
$route['logout'] = 'main_controller/logout';

$route['install'] = 'install_controller';
$route['install/start_install'] = 'install_controller/start_install';

$route['dashboard'] = 'main_controller/dashboard';
$route['admin']	= 'public_controller/login';
$route['create'] = 'main_controller/create';
$route['create/process_create'] = 'main_controller/process_create';
$route['delete/(:any)'] = 'main_controller/delete/$1';
$route['update/(:any)'] = 'main_controller/update/$1';
$route['(:any)'] = 'public_controller/read/$1';

$route['update/image_remove'] = 'main_controller/image_remove';
$route['update/update_new_image'] = 'main_controller/update_new_image';
$route['update/update_post'] = 'main_controller/update_post';

//default_controller must be set to 'install_controller' before starting installation
//then set to 'public_controller' after installation
$route['default_controller'] = 'public_controller/angular_index'; 
$route['not_found'] = 'public_controller/not_found';
$route['404_override'] = 'public_controller/not_found';


/* End of file routes.php */
/* Location: ./application/config/routes.php */