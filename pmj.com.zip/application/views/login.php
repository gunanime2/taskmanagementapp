<div class='row'>
	<div class='col-sm-4'>
	</div>
	<div class='col-sm-4'>
		<h2>Login</h2>
		<div class='' id='result-stage'>
		</div>
		<div class='form-group'>
			<label for='username'>Username</label>
			<input type='text' class='form-control' id='username' name='username'/>
		</div>
		<div class='form-group'>
			<label for='password'>Password</label>
			<input type='password' class='form-control' id='password' name='password'/>
		</div>
		<div class='form-group'>
			<button class='btn btn-info' type='button' id='login'>Login</button>
		</div>
	</div>
	<div class='col-sm-4'>
	</div>
</div>