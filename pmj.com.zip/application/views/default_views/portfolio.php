<!--portfolio-->
<?php if($works){ ?>
	<div class="col-sm-12">
		<h2><?php echo $title; ?></h2>
		<?php foreach($works as $work){ ?>
		<div class="col-sm-12 panel">
			<div class="col-sm-6">
				<img class="img-responsive" src="<?php echo base_url().'images/uploads/'.$work['image_url'];?>" class="img-responsive" alt="" />
			</div>
			<div class="col-sm-6">
				<a href="<?php echo base_url().$work['url'];?>">
					<b class="lead"><?php echo $work['title']?></b>
				</a>
				<p><?php echo word_limiter($work['content'], 100); ?></p>
			</div>
		</div>
		<?php } ?>
	</div>
<?php } ?>