
<?php foreach ($posts as $post):?>
<div class='row'>
	<div class='col-sm-12'>
		<a href='<?php echo base_url().$post['url'];?>'><h3><?php echo $post['title'];?></h3></a>
	</div>
	<?php if($post['image_url']){ //if the post item have a picture.?>
	<div class='col-sm-4'>
			<img src='<?php echo base_url().'images/uploads/'.$post['image_url'];?>' style='width:100%;'/>
	</div>
	<div class='col-sm-8 text-justify'>
		<?php echo word_limiter(strip_tags($post['content']),50);?>
	<br/>
	<a href='<?php echo base_url().$post['url'];?>'>Read more...</a>
	</div>
	<?php }else{?>
	
	<div class='col-sm-12 text-justify'>
		<?php echo word_limiter(strip_tags($post['content']),50);?>
	<br/>
	<a href='<?php echo base_url().$post['url'];?>'>Read more...</a>
	</div>
	<?php }?>
</div>
<?php endforeach?>