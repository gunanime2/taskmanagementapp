<h3 class='text-danger'>Image Upload Error!</h3>
<div class='form-group'>
	<label for='image_reupload'>Select File:</label>
	<input type='file' class='form-control' id='image_reupload' name='image_reupload'>
</div>