
<?php header('Content-Type: text/css'); ?>
<style type='text/css'>

body{
	//This part is not loaded.
}

body{
	font-family:<?php echo $style['body_font_family']; ?>;
	font-size:<?php echo $style['body_font_size']; ?>;
	background-color:<?php echo $style['body_background_color']; ?>;
}

.main-container{
	max-width:<?php echo $style['body_maximum_width']; ?>;
}

/*------------------HEADER    START---------------------*/

header{
	border-top:<?php echo $style['article_header_text_color']; ?> solid 5px;
	background-color:<?php echo $style['header_background_color']; ?>;
	color:<?php echo $style['header_normal_text_color']; ?>;
}

header h1,header h2,header h3,header h4{
	color:<?php echo $style['header_header_text_color']; ?>;
}

header a h1:hover, header a h2:hover, header a h3:hover, header a h4:hover{
	color:<?php echo $style['header_link_text_color'];?>;
}

header a{
	color:<?php echo $style['header_link_text_color']; ?>;
}header a:hover{
	color:<?php echo $style['header_link_text_color']; ?>;
}

/*-------------------HEADER    END------------------------*/

/*------------------ARTICLE    START----------------------*/
article{
	background-color:<?php echo $style['article_background_color']; ?>;
	color:<?php echo $style['article_normal_text_color']; ?>;
}

article h1,article h2,article h3,article h4{
	color:<?php echo $style['article_header_text_color']; ?>;
}article a h1:hover,article a h2:hover,article a h3:hover,article a h4:hover{
	color:<?php echo $style['article_link_text_color'];?>;
}

article a{
	color:<?php echo $style['article_link_text_color']; ?>;
}article a:hover{
	color:<?php echo $style['article_link_text_color']; ?>;
}
/*-------------------ARTICLE    END---------------------*/


/*-----------------WIDGET    START---------------------*/
.widget-header-custom{
	border-left:5px <?php echo $style['article_normal_text_color'] ?> solid;
}
/*-----------------WIDGET    END---------------------*/

/*-----------------FOOTER    START---------------------*/

footer{
	background-color:<?php echo $style['footer_background_color']; ?>;
	color:<?php echo $style['footer_normal_text_color']; ?>;
}

footer h1,footer h2,footer h3,footer h4{
	color:<?php echo $style['footer_header_text_color']; ?>;
}footer a h1:hover,footer a h2:hover,footer a h3:hover,footer a h4:hover{
	color:<?php echo $style['footer_link_text_color'];?>;
}

footer a{
	color:<?php echo $style['footer_link_text_color']; ?>;
}footer a:hover{
	color:<?php echo $style['footer_link_text_color']; ?>;
}

/*-----------------FOOTER    END----------------------*/

/*-----------------CAROUSEL START-----------------*/
.carousel-caption h2, .carousel-caption h3, .carousel-caption p{
	background-color: #009966;
	background-color: rgba(165, 165, 165, 0.6);
}
/*-----------------CAROUSEL END--------------------*/
</style>
