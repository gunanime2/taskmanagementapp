<div class="col-sm-12" ng-controller="dashboard_controller">
	<div class="col-sm-3">
		<h4>Navigation</h4>
		<ul class="nav nav-tabs nav-stacked">
			<li><a href="#main" ng-click="show_default();show_tasks='false';show_home='true'"><i class='fa fa-home'></i> Home</a></li>
			<li><a href="#tasks" ng-click="show_default();show_home='false';show_tasks='true'"><i class='fa fa-server'></i> Tasks</a></li>
			<li><a href="#units" ng-click="show_default();show_home='false';show_units='true'"><i class='fa fa-desktop'></i> Units</a></li>
			<li><a href="#users" ng-click="show_default();show_home='false';show_users='true'"><i class='fa fa-user'></i> Users</a></li>
		</ul>
		
		<h4>Details</h4>
		<ul class="nav nav-tabs nav-stacked">
			<li><a href="#user">User: {{username}}</a></li>
			<li>
				<a href="#user">Team: {{current_team_name}}
					<button class="btn btn-danger btn-xs" ng-click="leave_team()"><i class='fa fa-close'></i></button>
				</a>
				<ul class="nav nav-tabs nav-stacked">
					Members
					<li class="list-group-item" ng-repeat="x in team_relations | filter:{status:1}">
						{{ x.username }}
					</li>
				</ul>
				<ul class="nav nav-tabs nav-stacked">
					Requests
					<li class="list-group-item" ng-repeat="x in team_relations | filter:{status:0}">
						{{ x.username }} <button class="btn btn-success btn-xs" ng-click="approve_team_join_request(x.join_requestor_id, x.team_id)"><i class="fa fa-plus"></i> Accept</button>
					</li>
				</ul>
			</li>
			<li><a href="../admin/password_update">Change Password</a></li>
		</ul>
	</div>
	<div class="col-sm-9">
		<div class="col-sm-12 well"  ng-show="show_home">
			<h4>Home <small>Task management app home page.</small></h4>
			<ul class="list-group">
			  <li class="list-group-item">
				<form class="form-inline">
						<div class="form-group">
							<input class="form-control" placeholder="Team Name" type="text" ng-model="new_team_name" required/>
							<button class="form-control btn btn-danger" ng-click="add_team()"><i class="fa fa-plus"></i> Team</button>
						</div>
				</form>
			  </li>
			  <li class="list-group-item" ng-repeat="x in teams">
				<span class="badge">{{x.author}}</span>
				{{ x.title }} 
				<br/>
				<button class="btn btn-xs" ng-click="delete_team(x.url)">
					<i class="fa fa-close"></i> Delete
				</button>
				<button class="btn btn-xs" ng-click="request_join_team(x.id, x.author_id)">
					<i class="fa fa-sign-in"></i> Join
				</button>
				<button class="btn btn-xs" ng-click="enter_team(x.id, x.url)">
					<i class="fa fa-sign-in"></i> Enter
				</button>
			  </li>
			</ul>
		</div>
		<div class="col-sm-12 form-group alert alert-info" id="system_message">
			{{system_message}}
		</div>
		<div class="col-sm-12 well" ng-show="show_tasks">
			<h4>Tasks <small>View all tasks.</small></h4>
			<div class="col-sm-12" ng-show="show_chosen_task" >
				<h4>Chosen Task: {{chosen_task}} <button class="btn btn-xs btn-danger" ng-click="chosen_task_close()"><i class="fa fa-close"></i> Close</button></h4>
				<div class='col-sm-12 table-responsive' style="float:left;overflow-y: auto;height:300px;">
					<table class="table">
						<tr class="table-row" ng-repeat="x in generated_tasks">
							<td>{{x.title}}</td>
							<td>{{x.task_status}}</td>
							<td>{{x.updater_username}}</td>
							<td>{{x.updater_user_id}}</td>
							<td>
								<span ng-if="x.task_status == 'Pending'">
									<a ng-click="set_generated_task_completed_click(x.task_id, x.generated_task_id)" class="btn btn-danger btn-xs"><i class='fa fa-check'></i> Set Completed</a>
								</span>
								<span ng-if="x.task_status == 'Completed'">
									<a ng-click="set_generated_task_pending_click(x.task_id, x.generated_task_id)" class="btn btn-success btn-xs"><i class='fa fa-close'></i> Set Pending</a>
								</span>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="col-sm-12">
				<h4>List of Tasks <small>{{add_task_alert_message}}</small></h4>
				<ul class="list-group">
				  <li class="list-group-item">
					<form class="form-inline">
						<div class="form-group">
							<input class="form-control" placeholder="Task Name" type="text" ng-model="new_task_name" required/>
							<input class="form-control" placeholder="Department" type="text" ng-model="new_task_department" required/>
							<button class="form-control btn btn-danger" ng-click="add_task()"><i class="fa fa-plus"></i> Task</button>
						</div>
					</form>
				  </li>
				  <li class="list-group-item" ng-repeat="x in tasks">
					<span class="badge">{{x.labels}}</span>
					<button class="btn btn-danger btn-xs" ng-click="delete_task(x.url)">
						<i class="fa fa-close"></i>
					</button>
					<button class="btn btn-success btn-xs" ng-click="generate_tasks(x.url, x.id, x.title)">
						<i class="fa fa-ravelry"></i>
					</button>
					<a ng-click="show_chosen_task_click(x.id, x.title)" href="#{{x.title}}"><i class="fa fa-plus-square-o"></i> {{ x.title }}</a>
					<hr/>
					<div class="progress">
						  <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="{{x.total_completed}}"
						  aria-valuemin="" aria-valuemax="{{x.total_tasks}}" style="min-width:5%;width:{{(x.total_completed/x.total_tasks)*100}}%">
							{{(x.total_completed/x.total_tasks)*100}}% Progress
						  </div>
					</div>
				  </li>
				</ul>
			</div>
		</div>
		<div class="col-sm-12 well" ng-show="show_units">
			<h4>Units <small>View all units. {{add_unit_alert_message}}</small></h4>
			<ul class="list-group">
				<li class="list-group-item">
					<form class="form-inline">
						<div class="form-group">
							<input class="form-control" placeholder="Unit Name" type="text" id="new_unit_name" ng-model="new_unit_name" required/>
							<input class="form-control" placeholder="Department" type="text" ng-model="new_unit_department" required/>
							<button class="form-control btn btn-danger" ng-click="add_unit()"><i class="fa fa-plus"></i> Unit</button>
						</div>
					</form>
				</li>
				<li class="list-group-item" ng-repeat="x in units">
					<span class="badge">{{x.labels}}</span>
					<button class="btn btn-danger btn-xs" ng-click="delete_unit(x.url)">
						<i class="fa fa-close"></i>
					</button>
					<a href="#{{x.title}}">{{ x.title }}</a>
				</li>
			</ul>
		</div>
		<div class="col-sm-12 well" ng-show="show_users">
			<h4>Users <small>View all users.</small></h4>
			<ul class="list-group">
				<li class="list-group-item">
					<form class="form-inline">
						<div class="form-group">
							<input class="form-control" placeholder="User Name" type="text" ng-model="new_user_name" required/>
							<input class="form-control" placeholder="User Password" type="password" ng-model="new_user_password" required/>
							<button class="form-control btn btn-danger" ng-click="add_user()"><i class="fa fa-plus"></i> User</button>
						</div>
					</form>
				</li>
				<li class="list-group-item" ng-repeat="x in users">
					<button class="btn btn-danger btn-xs" ng-click="delete_user(x.id)">
						<i class="fa fa-close"></i>
					</button>
					<a href="#{{x.id}}">{{ x.name }}</a>
				</li>
			</ul>
		</div>
		
	</div>

</div>
