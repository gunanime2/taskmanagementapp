<div class="col-sm-12" ng-controller="login_controller">
	<div class="col-sm-12" id="register_form" ng-show="show_register">
		<div class="col-sm-2">
		</div>
		<div class="col-sm-8 well">
			<h4>Registration Form</h4>
			<div class="form-group alert {{register_alert_color}}">
				{{ register_message }}
			</div>
			<div class="form-group">
				<div class="input-group margin-bottom-md">
				  <span class="input-group-addon"><i class="fa fa-address-card fa-fw"></i></span>
				  <input class="form-control" type="text" placeholder="Name" ng-model="new_name">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group margin-bottom-md">
				  <span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
				  <input class="form-control" type="email" placeholder="Email" ng-model="new_email">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group margin-bottom-md">
				  <span class="input-group-addon"><i class="fa fa-user-circle fa-fw"></i></span>
				  <input class="form-control" type="text" placeholder="Username" ng-model="new_username">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group margin-bottom-md">
				  <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
				  <input class="form-control" type="password" placeholder="Password" ng-model="new_password">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<button class='btn btn-success' type='button' ng-click="try_register()">
						<i class="fa fa-user-circle-o fa-lg"></i>
						Create Account
					</button>
					<span> | </span>
					<button class='btn btn-warning' type='button' ng-click="show_register=!show_register; show_login=!show_login">
						<i class="fa fa-close fa-lg"></i>
						Cancel
					</button>
				</div>
			</div>
		</div>
		<div class="col-sm-2">
		</div>
	</div>
	<div class="col-sm-12" id="login_form" ng-show="show_login">
		<div class='col-sm-2'>
		</div>
		<div class='col-sm-8 well'>
			<h4>Login Form</h4>
			<div class="form-group alert {{alert_color}}">
				{{ login_message }}
			</div>
			<div class="form-group text-center" ng-show="show_loading">
				<i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>
				<span class="sr-only">Loading...</span>
			</div>
			<div class="form-group">
				<div class="input-group margin-bottom-md">
				  <span class="input-group-addon"><i class="fa fa-user-o fa-fw"></i></span>
				  <input class="form-control" type="text" placeholder="Username" ng-model="username">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
				  <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
				  <input class="form-control" type="password" placeholder="Password" ng-model="password">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<button class='btn btn-danger' type='button' ng-click="try_login()">
						<i class="fa fa-user-circle-o fa-lg"></i>
						Login
					</button>
					<span> | </span>
					<button class='btn btn-info' type='button' ng-click="show_register_click()">
						<i class="fa fa-vcard fa-lg"></i>
						Register
					</button>
				</div>
			</div>
		</div>
		<div class='col-sm-2'>
		</div>
	</div>
</div>