<div class="container">
	<h3>Angular App</h3>
	
	<?php	//check if the user is logged-in 
			if($this->session->userdata('user_validated')){
			//If the user is logged in, show the dashboard
	?>
		<div class="col-sm-12">
			<h4>Dashboard</h4>
		</div>
	<?php 	}else{ 
			//if the user is not logged in, show the login form
	?>
		<div class="col-sm-12" ng-controller="login_controller">
			<div class="col-sm-12" id="login_form">
				<h4>Login</h4>
				<div class='col-sm-4'>
					<div class="form-group alert {{alert_color}}">
						{{ login_message }}
					</div>
					<div class="form-group text-center" ng-show="show_loading">
						<i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>
						<span class="sr-only">Loading...</span>
					</div>
					<div class="form-group">
						<div class="input-group margin-bottom-md">
						  <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
						  <input class="form-control" type="text" placeholder="Username" ng-model="username">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
						  <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
						  <input class="form-control" type="password" placeholder="Password" ng-model="password">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<button class='btn btn-danger' type='button' ng-click="try_login()">
								<i class="fa fa-user-circle-o fa-lg"></i>
								Login
							</button>
							<span> | </span>
							<button class='btn btn-info' type='button' ng-click="show_register_click()">
								<i class="fa fa-vcard fa-lg"></i>
								Register
							</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12" id="register_form" ng-show="show_register">
				<h4>Register</h4>
			</div>
		</div>
	<?php } ?>
</div>