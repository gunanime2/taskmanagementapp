<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta class="og-image" property="og:image" content="" />
    <title><?php 
	
	if(!empty($title)){
		echo $title;
	}elseif(!empty($post['title'])){
		echo $post['title'];
	}
	?> 
	| <?php echo $web_app_name; ?>
	</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!--My CSS-->
	<link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/generated_css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/inormoc_style.css" rel="stylesheet">
  </head>
  <body>
    <div class='container-fluid main-container' >

		<header class='clearfix'>
			<nav class="mobile-navbar-custom hidden-lg hidden-md hidden-sm">
				<div class="cols-sm-12">
					<div class="mobile-navbar-button">
						<a href="#">
							<span>Menu</span>
							<span class="glyphicon glyphicon-list"></span>
						</a>
					</div>
					<div class="nav-links-wrapper">
					</div>
					<div class="mobile-brand-custom text-center">
					</div>
				</div>
			</nav>
			<nav class="navbar-custom hidden-xs">
				<div class="col-md-6 brand-custom">
					<a href="./"><img src="<?php echo base_url();?>images/logo.png"></p></a>
				</div>
				<div class="col-md-6 navbar-links-custom">
					<ul>
						<li><a href="<?php echo base_url(); ?>">Home</a></li>
						<li><a href="<?php echo base_url().'download_0'; ?>">Download</a></li>
						<li><a href="<?php echo base_url().'instructions_5'; ?>">Instructions</a></li>
						<li><a href="<?php echo base_url().'about_1'; ?>">About</a></li>
						<?php if($this->session->userdata('user_validated')){?>
						<li><a href='<?php echo base_url().'dashboard';?>'>Dashboard</a></li>
						<li><a href='<?php echo base_url().'logout';?>'>Log Out</a></li>
						<?php }?>
					</ul>
				</div>
			</nav>
		</header>
		
		<article class='clearfix'>
			<?php 
			if(!empty($featured)){ ?>
			<!--carousel-->
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-example-generic" data-slide-to="1"></li>
					<li data-target="#carousel-example-generic" data-slide-to="2"></li>
				  </ol>
					<div class="carousel-inner" role="listbox">
						<?php	
							$active = 1;
							foreach($featured as $post):?>
						<!-- Wrapper for slides -->
						<div class="<?php if($active>0){echo 'item active'; $active--;}else{echo 'item';}?>">
							<img class="img-responsive carousel-image-custom" src="<?php echo base_url().'images/uploads/'.$post['image_url'];?>" alt="..."/>
							<div class="carousel-caption hidden-lg hidden-md small-carousel hidden-sm">
								<p class="lead"><?php echo $post['title'];?></p>
							</div>
							<div class="carousel-caption hidden-xs">
								<p class="lead"><?php echo $post['title'];?></p>
								<p><?php echo word_limiter(strip_tags($post['content']), 20);?></p>
							</div>
						</div>
						<?php endforeach ?>
					</div>
				  <!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				  </a>
				</div>
				<!---->
				<?php } ?>
			<div class='col-sm-12'>
				<div class="row">
				<?php if(!empty($side_bar)){ ?>
					<div class="col-sm-8 post-sidebar">
						<?php	echo $body; ?>
					</div>
					<div class="col-sm-4">
						<?php	echo $side_bar;?>
					</div>
				<?php }else{ ?>
					<div class="col-sm-12">
						<?php	echo $body; ?>
					</div>
				<?php } ?>
				</div>
			</div>
		</article>
		<footer>
			<div class='container-fluid footer-wrapper-custom'>
				<div class='col-sm-12'>
					<span>45 CMS V1.2</span>
				</div>
			</div>
			<div class='col-sm-12 text-center'>
				<span>Powered By iLisondra Designs</span><br/>
				<span>Hosted By <a href="http://leytewebhost.com/" target="_blank">LeyteWebHost</a></span><br/>
				<small>Copyright© 2015 - All Rights Reserved</small>
			</div>
		</footer>
	</div>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
    <script src="<?php echo base_url();?>js/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>js/script.js"></script>
	

	
	<!--wysywig-->
	<!-- <script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script> -->
	<script src="<?php echo base_url();?>js/tinymce/tinymce.min.js"></script>
	<script>tinymce.init({selector: "textarea",
    theme: "modern",
    plugins: [
        "advlist autolink lists link print hr anchor",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime nonbreaking save table contextmenu directionality",
        "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "print preview media | forecolor backcolor emoticons",
    image_advtab: true,
    templates: [
        {title: 'Test template 1', content: 'Test 1'},
        {title: 'Test template 2', content: 'Test 2'}
    ]});</script>
  </body>
</html>