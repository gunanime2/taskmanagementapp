<?php echo 'Error:'.validation_errors(); 

		if(isset($error)){
			echo $error;
		}
?>