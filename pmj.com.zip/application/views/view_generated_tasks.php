<?php //var_dump($posts); ?>
<div class='row'>
	<div class='container-fluid'>
		<h3><?php echo $title; ?></h3>
		<div class='col-sm-12 result-stage' id='result-stage'style='display:none;'></div>
		<div class='col-sm-12 table-responsive'>
			<table class='table'>
				<tr>
					<td><strong>Unit</strong></td>
					<td><strong>Status</strong></td>
					<td><strong>Date Updated</strong></td>
					<td><strong>Updated By</strong></td>
					<td><strong>Actions</strong></td>
				</tr>
				<?php foreach($posts as $post):?>
				<tr class='table-row'>
					<td><?php echo $post['title']; ?></td>
					<td class="<?php if($post['task_status']=='Pending'){echo "bg-danger";}else{echo "bg-success";} ?>"><?php echo $post['task_status']; ?></td>
					<td><?php echo $post['date_generated']; ?></td>
					<td><?php echo $post['updater_user_id']; ?></td>
					<td><button class='btn btn-primary btn-xs show_update_generated_task_status_modal' data-generated-task-id="<?php echo $post['generated_task_id'];?>" data-toggle="modal" data-target="#UpdateBotStatusModal">Update <span class='glyphicon glyphicon-pencil'></span></button></td>
				</tr>
				<?php endforeach ?>
			</table>
		</div>
	</div>
</div>

<!--Bootstrap Modals-->
<div class="modal fade" id="UpdateBotStatusModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header bg-primary">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel"><span class="glyphicon glyphicon-list"></span> Update Generated Task Status</h4>
		  </div>
		  <div class="modal-body">
			<div id="UpdateTaskStatusResultSuccess" class="bg-success" hidden>
				<strong>You have successfully updated the generated tasks status.</strong>
				<p>
					The records will now be refreshed. Please wait.
				</p>
			</div>
			<div id="UpdateTaskStatusResultFail" class="bg-danger" hidden>
				<strong>Failed updating the generated tasks status.</strong>
				<p>
					The records will now be refreshed. Please wait.
				</p>
			</div>
			<div id="UpdateTaskStatusModalInitialContent">
				<p>
					Hello <?php echo $this->session->userdata('username'); ?>. 
					You are about to update this generated tasks' status. 
					Please continue only if you are sure.
				</p>
				<p>
					<h5>Update generated task status as:</h5>
					<button type="button" class="btn btn-success update_generated_task_status" data-update-type="Completed"><span class="glyphicon glyphicon-check"></span> Completed</button>
					<button type="button" class="btn btn-default update_generated_task_status" data-update-type="Pending"><span class="glyphicon glyphicon-cog"></span> Pending</button>
				</p>
			</div>
			<div id="UpdateTaskStatusModalConfirmationContent" hidden>
				<p>
					<h5>Do you want to continue?</h5>
					<button type="button" class="btn btn-success confirm_generated_task_update" data-update-type="" data-generated-task-id=""><span class="glyphicon glyphicon-check"></span> Yes</button>
					<button type="button" class="btn btn-default cancel-generated-task-status-update"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
				</p>
			</div>
		  </div>
		  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
		  </div>
		</div>
	</div>
</div>