<div class='row'>
	<div class='container-fluid'>
		<h2>Admin Dashboard</h2>
		<div class='col-sm-12 result-stage' id='result-stage'style='display:none;'></div>
		<div class='col-sm-12'>
			<div class="btn-group col-sm-6" role="group" aria-label="...">
				<a class='btn btn-default btn-sm' href='<?php echo base_url();?>create'>Create <span class="glyphicon glyphicon-pencil"></span></a>
				<a class='btn btn-default btn-sm' href='<?php echo base_url();?>admin/password_update'>Update Password <span class="glyphicon glyphicon-edit"></span></a>
				<a class='btn btn-default btn-sm' href='<?php echo base_url();?>admin/modify_appearance'>Modify Appearance <span class="glyphicon glyphicon-cog"></span></a>
			</div>
			<div class='col-sm-6'>
				
			</div>
		</div>
		<div class='col-sm-12 table-responsive'>
			<table class='table'>
				<tr>
					<td><strong>Post Id</strong></td><td><strong>Date Posted</strong></td><td><strong>Post Title</strong></td><td><strong>Type</strong></td><td><strong>Labels</strong></td><td><strong>Actions</strong></td>
				</tr>
				<?php foreach($posts as $post):?>
				<tr class='table-row'>
					<?php
						echo "<td>".$post['id']."</td>";
						echo "<td>".$post['date']."</td>";
						echo "<td>".$post['title']."</td>";
						echo "<td>".$post['type']."</td>";
						echo "<td>".$post['labels']."</td>";
						echo "<td><span style='display:none;'><a class='btn btn-danger confirm_delete btn-xs' data='".base_url()."delete/".$post['url']."'>Confirm Delete</a>";
						echo " <a class='btn btn-warning cancel_delete btn-xs'>Cancel</a></span>";
						echo " <a class='btn btn-info btn-xs' href='".base_url().$post['url']."'>View <span class='glyphicon glyphicon-eye-open'></span></a>";
						echo " <a class='btn btn-warning btn-xs' href='".base_url()."update/".$post['url']."'>Edit <span class='glyphicon glyphicon-edit'></span></a>";
						echo " <a class='btn btn-danger show_delete btn-xs'>Delete <span class='glyphicon glyphicon-remove-circle'></span></a></td>";
					?>
				</tr>
				<?php endforeach ?>
			</table>
		</div>
	</div>
</div>