$(document).ready(function(){
//	20151014
//	Specially created js file for the error that the fancybox plugin causes to
// 	the applications create_new post function.

//fancybox photo plugin
	$(".fancybox").fancybox();
	
});