var app = angular.module('app_main', []);
var base_url = "http://localhost/pmj.com/";

app.controller('main_controller', function($scope, $http){
	$scope.base_url = "http://localhost/pmj.com/";
});

app.controller('dashboard_controller', function($scope, $http, $timeout){

	//default values
	$scope.show_tasks = true;
	$scope.show_home = false;
	$scope.show_default;
	get_teams();
	get_user_name();
	get_tasks();
	get_units();
	get_current_details();
	$scope.username = 'None';
	$scope.current_team_name = 'None';
	$scope.system_message = 'System message balloon.';

	$scope.show_default = function(){
		clear_fields();
		$scope.show_home = false;
		$scope.show_tasks = false;
		$scope.show_units = false;
		$scope.show_users = false;
		$scope.show_chosen_task = false;
	}
	
	function clear_fields(){
		//$scope.new_unit_name = "";
		//$scope.new_unit_department = "";
		$scope.new_task_name = "";
		$scope.new_task_department = "";
		$scope.new_team_name = "";
		$scope.new_user_name = "";
		$scope.new_user_password = "";
	}
	
	function system_message_update(message){
		$scope.system_message = 'System message: '+message;
		$timeout(function(){
			$scope.system_message = "System message: No new message.";
		}, 5000);
	}
	
	//get team relations
	function get_team_relations(team_id){
		$http.post($scope.base_url+"angular/angular_get_team_relations/"+team_id).success(
			function(data){
				$scope.team_relations = data.team_relations;
			}
		);
	}
	
	//get username
	function get_user_name(){
		$http.post($scope.base_url+"angular/get/user/username").success(function(data){
			$scope.username = data.username;
		});
	}
	
	//get current details
	function get_current_details(){
		$http.post($scope.base_url+"angular/get_current_details").success(
			function(data){
				$scope.current_team_name = data.current_team_name;
			}
		);
	}
	
	//get all teams
	function get_teams(){
		$http.post($scope.base_url+"angular/get/team").success(function(data){
			$scope.teams = data;
			clear_fields();
		});
	}
	
	//get all tasks
	function get_tasks(){  
		$http.post($scope.base_url+"angular/get/task").success(function(data){
			$scope.tasks = data;
			clear_fields();
		});
	};
	
	//get all units
	function get_units(){
		$http.post($scope.base_url+"angular/get/unit").success(function(data){
			$scope.units = data;
			clear_fields();
		});
	}
	
	//get all users
	function get_users(){
		$http.post($scope.base_url+"angular/get/users").success(function(data){
			$scope.users = data;
			clear_fields();
		});
	}
	
	//get specific task
	function get_chosen_tasks(task_id, task_title){
		$http.post($scope.base_url+"angular/get/task/"+task_id).success(function(data){
			$scope.generated_tasks = data;
			clear_fields();
		});
	}
	

	//set generated task's status to completed
	$scope.set_generated_task_completed_click = function(task_id, generated_task_id){
		$http.post($scope.base_url+"angular/update_task_status/completed/"+generated_task_id).success(
			function(){
				$http.post($scope.base_url+"angular/get/task/"+task_id).success(function(data){
					$scope.generated_tasks = data;
				});
				get_tasks();
			}
		);
	}
	
	//set generated task's status to pending
	$scope.set_generated_task_pending_click = function(task_id, generated_task_id){
		$http.post($scope.base_url+"angular/update_task_status/pending/"+generated_task_id).success(
			function(){
				$http.post($scope.base_url+"angular/get/task/"+task_id).success(function(data){
					$scope.generated_tasks = data;
				});
				get_tasks();
			}
		);
	}
	
	$scope.show_chosen_task_click = function(task_id, task_title){
		get_chosen_tasks(task_id, task_title);
		$scope.chosen_task = task_title;
		$scope.show_chosen_task = true;
	}
	
	$scope.chosen_task_close = function(){
		$scope.show_chosen_task = false;
	}
	
	//show_chosen_task
	function show_chosen_task(task_id, task_title){
		get_chosen_tasks(task_id, task_title);
		$scope.chosen_task = task_title;
		$scope.show_chosen_task = true;
	}
	
	//generate_tasks
	$scope.generate_tasks = function(task_url, task_id, task_title){
		$http.post($scope.base_url+"confirm_generate/"+task_url).success(
			function(data){
				show_chosen_task(task_id, task_title);
				system_message_update(data.system_message);
				get_tasks();
			}
		);
	}
	
	//add task
	$scope.add_task = function(){$http({
			method		: "POST",
			url			: $scope.base_url+"angular/add_task",
			data		:{
				new_task_name: $scope.new_task_name,
				new_task_department: $scope.new_task_department
			}
		}).then(function add_task_success(response){
			$scope.add_task_result = response.data.add_task_result;
			
			if(!$scope.add_task_result){
				$scope.add_task_alert_color = "alert-danger";
				system_message_update("Add task failed.");
			}else{
				$scope.add_task_alert_color = "alert-success";
				system_message_update("Task Created Successfully");
			}
			
			$scope.show_add_task_alert = true;
			get_tasks();
		}, function add_task_error(response){
			system_message_update(response.statusText);
		});
	}
	
	//delete task
	$scope.delete_task = function(task_url){
		$http.post($scope.base_url+"angular/delete_task/"+task_url).success(
			function(data){
				system_message_update(data.system_message);
				get_tasks();
				$scope.generated_tasks = "Nothing Found.";
				$scope.show_chosen_task = false;
			}
		);
	}
	
	//add unit
	$scope.show_add_unit_alert = false;
	$scope.add_unit = function(){$http({
			method		: "POST",
			url			: $scope.base_url+"angular/add_unit",
			data		:{
				new_unit_name: $scope.new_unit_name,
				new_unit_department: $scope.new_unit_department
			}
		}).then(function add_unit_success(response){
			$scope.add_unit_result = response.data.add_unit_result;
			
			if(!$scope.add_unit_result){
				$scope.add_unit_alert_color = "alert-danger";
				system_message_update("Add unit failed.");
			}else{
				$scope.add_unit_alert_color = "alert-success";
				system_message_update("Unit Created Successfully");
			}
			
			$scope.show_add_unit_alert = true;
			get_units();
		}, function add_unit_error(response){
			system_message_update(response.statusText);
		});
	}
	
	//delete unit
	$scope.delete_unit = function(unit_url){
		$http.post($scope.base_url+"angular/delete_unit/"+unit_url).success(
			function(data){
				system_message_update(data.system_message);
				get_units();
			}
		);
	}
	
	//add user
	$scope.add_user = function(){$http({
			method		: "POST",
			url			: $scope.base_url+"angular/add_user",
			data		:{
				new_user_name: $scope.new_user_name,
				new_user_password: $scope.new_user_password
			}
		}).then(function add_user_success(response){
			system_message_update(response.data.add_user_result);

			get_users();
		}, function add_user_error(response){
			system_message_update(response.statusText);
		});
	}
	
	//delete user
	$scope.delete_user = function(user_id){
		$http.post($scope.base_url+"angular/delete_user/"+user_id).success(
			function(){
				get_users();
			}
		);
	}
	
	//add team
	$scope.add_team = function(){
		if($scope.new_team_name != ""){
			$http({
				method		: "POST",
				url			: $scope.base_url+"angular/add_team",
				data		:{
					new_team_name: $scope.new_team_name
				}
			}).then(function add_team_success(response){
				system_message_update(response.data.add_team_result);

				get_teams();
			}, function add_team_error(response){
				system_message_update(response.statusText);
			});
		}else{
			//Please check your inputs.
			system_message_update("Please check your inputs.");
		}
	}
	
	//delete team
	$scope.delete_team = function(team_id){
		$http.post($scope.base_url+"angular/delete_team/"+team_id).success(
			function(data){
				system_message_update(data.system_message);
				get_teams();
			}
		);
	}
	
	//enter team
	$scope.enter_team = function(team_id, team_url){
		$http.post($scope.base_url+"angular/enter_team/"+team_id+"/"+team_url).success(
			function(data){
				//system_message_update(data.system_message);
				system_message_update(data.system_message);
				$scope.current_team_details = data.current_team_details;
				$scope.users = data.users;
				get_tasks();
				get_units();
				get_current_details();
				get_team_relations(team_id);
			}
		);
	}
	
	//leave team
	$scope.leave_team = function(){
		$http.post($scope.base_url+"angular/leave_team").success(
			function(){
				get_teams();
				get_tasks();
				get_units();
				get_chosen_tasks("","");
				get_current_details();
			}
		);
	}
	
	//request to join team
	$scope.request_join_team = function(team_id, author_id){
		$http.post($scope.base_url+"angular/request_join_team/"+team_id+"/"+author_id).success(
			function(data){
				system_message_update(data.system_message);
			}
		);
	}
	
	//approve join team request
	$scope.approve_team_join_request = function(join_requestor_id, team_id){
		$http.post($scope.base_url+"angular/angular_approve_team_join_request/"+team_id+"/"+join_requestor_id).success(
			function(data){
				system_message_update(data.system_message);
				get_team_relations(team_id);
			}
		);
	}
});

app.controller('login_controller', function($scope, $http, $timeout){
	$scope.login_message = "Fill up the form to login. Demo accounts: account: admin, pw: admin | account: user, pw: user";
	$scope.alert_color = "alert-info";
	$scope.show_register = false;
	$scope.show_login = true;
	$scope.show_loading = false;
	
	$scope.register_message = "Create new account.";
	$scope.register_alert_color = "alert-info";
	
	$scope.show_register_click = function(){
		$scope.show_register = !$scope.show_register;
		$scope.show_login = !$scope.show_login;
	}
	
	$scope.try_register = function(){$http({
			method		: "POST",
			url			: base_url+"angular/register_attempt",
			data		:{
				new_username: $scope.new_username,
				new_password: $scope.new_password,
				new_email: $scope.new_email,
				new_name: $scope.new_name
			}
		}).then(function register_success(response){
			//store the boolean result to a variable
			$scope.register_result = response.data.register_result;
			
			//check if the server returned a true value
			if(!$scope.register_result){
				//if the server returned a false value to the register attempt
				$scope.register_alert_color = "alert-danger";
				$scope.register_message = "Failed to create account. Review your inputs and try again.";
			}else{
				//if the server returned a true value to the register attempt
				$scope.register_alert_color = "alert-success";
				$scope.register_message = "Account created successfully. You can now login.";
				//show the login form after 2 seconds
				$timeout(function(){
					$scope.show_register = false;
					$scope.show_login = true;
				}, 2000);
			}
		}, function register_error(response){
			$scope.resgiter_result = response.statusText;
		});
	}

	$scope.try_login = 	function(){$http({
			method		: "POST",
			url			: base_url+"angular/login_attempt",
			data		:{
				username: $scope.username,
				password: $scope.password
			}
		}).then(function mySuccess(response){
			$scope.myResult = response.data.login_result;
			$scope.logging_in = false;
			if(!$scope.myResult){
				$scope.alert_color = "alert-danger";
				$scope.login_message = "Failed to login, try again.";
			}else{
				$scope.show_loading = !$scope.show_loading;
				$scope.alert_color = "alert-success";
				$scope.login_message = "Login success. Redirecting to the dashboard...";
				$timeout(function(){
					window.location = base_url+"angular/angular_dashboard";
				}, 2000);
			}
		}, function myError(response){
			$scope.myResult = response.statusText;
		});
	}

});