$(document).ready(function(){
	var base_url = 'http://localhost/pmj.com';
	
	//	20151025
	//	"Universal Submit"
	//	A function that will be called each time the universal
	// 	submit button was clicked by the user.
	// 	This function uses the formData functionality of JQuery
	// 	and sends all the data contained in a formdata form 
	//	into a PHP parser.
	//	Uses the submit-to attribute of the universal_submit button to
	//	locate or determine the PHP parser.
	$("#universal_submit").click(function(e){
		var parse_to = $("#universal_submit").attr("submit-to");
		var formData = new FormData($("#data")[0]);
		$.ajax({
			url: parse_to,
			type: 'POST',
			data: formData,
			success: function(data){
				if(data != 'failed'){
					$(".result-stage").hide(function(){
						$(".result-stage").html('<h3>Success <small>Process successful.</small></h3>');
						$(".result-stage").show();
					});
				}else{
					$(".result-stage").hide(function(){
						$(".result-stage").html('<h3>Failed <small>Something went worng.</small></h3>');
						$(".result-stage").show();
					});
				}
			},
			cache: false,
			contentType: false,
			processData: false
		});
		return false;
	});
	
	
	//change_password
	$("#change_password").click(function(){
		var current_password = $("#current_password").val(),
			new_password = $("#new_password").val(),
			confirm_new_password = $("#confirm_new_password").val();
	
		$.ajax({
			type:"post",
			url:"../admin/password_update_process",
			data:"current_password="+current_password+"&new_password="+new_password+"&confirm_new_password="+confirm_new_password,
			dataType: "json",
			success: function(data){
				if(data['status'] === "success"){
					$(".password_update_form").toggle(500);
					$(".result_stage").show(function(){
						$(".result_stage").html(data['message']);
					});
				}else{
					$(".result_stage").show(function(){
						$(".result_stage").html(data['message']);
					});
				}
			}
		});
	});
	
	//Facebook Open Graph
	var og_image = $(".main-image-custom").attr("src");
	//$('meta[name=description]').attr('content', 'new value');
	$(".og-image").attr("content", og_image);
	
	//for responsive mobile nav
	var nav_lists = $(".navbar-links-custom").html();
	$(".mobile-navbar-custom div .nav-links-wrapper").html(nav_lists);
	
	var brand = $(".brand-custom").html();
	$(".mobile-brand-custom").html(brand);
	
	$(".mobile-navbar-custom div .mobile-navbar-button").click(function(){
		$(".mobile-navbar-custom div .nav-links-wrapper ul").toggle(500);
	});
	//end
	
	//$(".list-group").toggle();
	
	$(".work-wrapper img").mouseover(function(){
		$(this).next('p').show(500);
	});
	
	$(".work-wrapper img").mouseout(function(){
		$(this).next('p').hide(500);
	});
	
	$(".show-list-group").click(function(e){
		var list = $(this).attr("target");
		$(list).toggle(500);
	});
	
	$("#create_post_old_fuck_not_fucking_working_fuck_this_code_3_days_of_figuring_out").click(function(e){
		var post_title = document.getElementById("post_title").value;
		var post_image = document.getElementById("post_image").value;
		var post_content = document.getElementById("post_content").value;
		var post_labels = document.getElementById("post_labels").value;
		if(post_title === "" && post_content === ""){
			return;
		}else{
			$.ajax({
				type: "post",
				url: "./create/process_create",
				enctype: 'multipart/form-data',
				data: "post_title="+post_title+"&post_image="+post_image+"&post_content="+post_content+"&post_labels="+post_labels,
				success: function(data){
					$('#stage').hide();
					var stage = document.getElementById('stage');
					stage.innerHTML = data;
					$('#stage').show(500);
				}
			});
		}
	});
	
	
	$("#create_post_working").click(function(e){
		var formData = new FormData($("#data")[0]);
		$.ajax({
			url: "./create/process_create",
			type: 'POST',
			data: formData, 
			async: false,
			success: function(data){
					$('#stage').hide();
					var stage = document.getElementById('stage');
					stage.innerHTML = data;
					$('#stage').show(500);
			},
			cache: false,
			contentType: false,
			processData: false
		});

		return false;
	});
	
	//	20151024
	//	This will be the new create post function.
	//	The purpose is to get the upload status from the server using json.
	//	The current one does not use json functionality and only relies on the formData method.
	//	Function task would be, upon user click on the submit button, verify if an image is selected.
	//	If an image is selected, send the image data to the PHP parser using AJAX with formData for uploading.
	//	Receive and process PHP parser result.
	//	If upload failed, alert the user.
	//	If upload success, send the text inputs to the PHP parser using AJAX with JSON.
	//	Receive and process PHP JSON parser result data.
	//	If failed, alert user.
	//	If success, hide the form then alert user.
	$("#create_post").click(function(e){
		if(post_title === "" && post_content === ""){
			return false;
		}else{
			if($("#post_image").val() != ""){
				upload_image();
			}else{
				upload_text_inputs('no_image_selected');
			}
		}
		
		function upload_image(){
			var formData = new FormData($("#data")[0]);
			$.ajax({
				url: "./create/process_create/upload_image",
				type: 'POST',
				data: formData,
				success: function(data){
					if(data != 'failed'){
						upload_text_inputs(data);
					}else{
						$('#stage').hide();
						var stage = document.getElementById('stage');
						stage.innerHTML = "<div class='bg-warning'><h2>Image Upload Failed<small>Please try selecting a different image.</small></h2></div>";
						$('#stage').show(500);
					}
				},
				cache: false,
				contentType: false,
				processData: false
			});
			return false;
		}
		
		function upload_text_inputs(data){
			if(data != 'failed'){
				var frameObj = document.getElementById('post_content_ifr');
				var frameContent = frameObj.contentWindow.document.body.innerHTML;
				$("#post_content").html(frameContent);
				var post_title = document.getElementById("post_title").value;
				var post_content = document.getElementById("post_content").value;
				var post_labels = document.getElementById("post_labels").value;
				var post_type = $( "#post_type" ).val();
				var post_image_name = data;
				$.ajax({
					type: "post",
					url: base_url+"/create/process_create/upload_text_inputs",
					data: "post_image_name="+post_image_name+"&post_type="+post_type+"&post_title="+post_title+"&post_content="+post_content+"&post_labels="+post_labels,
					dataType: "json",
					success: function(data){
						if(data['status'] === "success"){
							$("#stage").hide(function(){
								$("#stage").html("<div class='bg-success'><h2>Post Published!<small>You have published a new post.</small></h2><p><a class='btn btn-success' href='"+base_url+"/"+data['url']+"'>View Post</a></p></div>");
								$("#data").hide();
								$("#stage").show();
							});
						}else{
							$("#stage").hide(function(){
								$("#stage").html("<div class='bg-warning'><h2>Failed<small>Please check yuor inputs.</small></h2></div>");
								$("#stage").show();
							});
						}
					}
				});
			}
		}
	});
	
	//	20151017
	//	Last create post function.
	//	Produces an error if the latest version of jquery(1.4) is loaded with the page.
	//	PHP parser don't seem to catch the values passed by jQuery.
	//	20151018
	//	I have just restored this old function for use.
	//	The function I was working on was not working. It sucked.
	$("#create_post_old_20151024").click(function(e){
		var frameObj = document.getElementById('post_content_ifr');
		var frameContent = frameObj.contentWindow.document.body.innerHTML;
		$("#post_content").html(frameContent);
		var formData = new FormData($("#data")[0]);
		$.ajax({
			url: "./create/process_create",
			type: 'POST',
			data: formData,
			success: function(data){
					$('#stage').hide();
					var stage = document.getElementById('stage');
					stage.innerHTML = data;
					$('#stage').show(500);
			},
			cache: false,
			contentType: false,
			processData: false
		});
		return false;
	});
	
	//scripts for update page
		//remove image
	$('#remove_image_working').click(function(e){
		var image = document.getElementById('image').name;
		$.ajax({
			type: "post",
			url: base_url+"/update/image_remove",
			data:"image="+image,
			success: function(data){
				$('#image_result_stage').hide();
				var stage = document.getElementById('image_result_stage');
				stage.innerHTML = data;
				$('.img-wrapper').hide();
				$('#image_result_stage').show(500);
				$('#image_result_stage').hide(2000);
				$('.img_upload_form').show(2000);
			}
	});
	});
	
	$('#remove_image').click(function(e){
		var image = document.getElementById('image').name;
		$.ajax({
			type: "post",
			url: base_url+"/update/image_remove",
			data:"image="+image,
			success: function(data){
				$('#image_result_stage').hide();
				var stage = document.getElementById('image_result_stage');
				stage.innerHTML = data;
				$('.img-wrapper').hide("slow",function(){
					$('#image_result_stage').show("slow",function(){
						$('#image_result_stage').hide("slow",function(){
							$('.img_upload_form').show(1000);
						});
					});
				});
			}
	});
	});
		
		//upload new image
	$('#upload_new_image').click(function(e){
		var formData = new FormData($("#update_image")[0]);
		$.ajax({
			url: base_url+"/update/update_new_image",
			type: 'POST',
			data: formData,
			async: false,
			success: function(data){
				/*$('#upload_new_image').hide();
				$('.img_upload_form').hide();
				$('#show_remove_image_btn').show();
				$('#remove_image_final_btn_wrapper').hide();
				$('#image_result_stage').hide();
				$('#image_result_stage').show("slow", function(){
					$('.img-wrapper').show();
				});*/
				$('#upload_new_image').hide(function(){
					$('.img_upload_form').hide(function(){
						$('#show_remove_image_btn').show(function(){
							$('#remove_image_final_btn_wrapper').hide(function(){
								$('#image_result_stage').hide(function(){
									$('#image_result_stage').show("slow", function(){
										$('.img-wrapper').show(function(){
											var stage = document.getElementById('image_result_stage');
											stage.innerHTML = data;
											var image_url = document.getElementById('new_image').value;
											$('#image').prop('src', image_url + '?' + Math.random())
										});
									});
								});
							});
						});
					});
				});
			},
			cache: false,
			contentType: false,
			processData: false
		});
		return false;
	});
	
	$('#image_update').change(function(){
		$('#upload_new_image').show();
	});
	
		//update the edited post
	$('#update_post').click(function(e){
		var frameObj = document.getElementById('post_content_ifr');
		var frameContent = frameObj.contentWindow.document.body.innerHTML;
		$("#post_content").html(frameContent);
		var post_url = document.getElementById('url').value;
		var post_title = document.getElementById("post_title").value;
		var post_content = document.getElementById("post_content").value;
		var post_labels = document.getElementById("post_labels").value;
		var post_type = $( "#post_type" ).val();
		if(post_title === "" && post_content === ""){
			return;
		}else{
			$.ajax({
				type: "post",
				url: base_url+"/update/update_post",
				data: "post_type="+post_type+"&post_url="+post_url+"&post_title="+post_title+"&post_content="+post_content+"&post_labels="+post_labels,
				success: function(data){
					$('#stage').hide();
					var stage = document.getElementById('stage');
					stage.innerHTML = data;
					$('#stage').show(500);
					$('#hidden_update_buttons').hide(function(){
						$('#show_update_post_buttons').show();
					});
				}
			});
		}
	});
	
		//confirm update buttons
	$('#show_remove_image_btn').click(function(e){
		$(this).hide(function(){
			$('#remove_image_final_btn_wrapper').show(500);
		});
	});
	
	$('#remove_image_cancel').click(function(e){
		$('#remove_image_final_btn_wrapper').hide(function(){
			$('#show_remove_image_btn').show(200);
		});
	});
	
	$('#show_update_post_buttons').click(function(){
		$(this).hide(200, function(){
			$('#hidden_update_buttons').show(200);
		});
	});
	
	$('#update_post_cancel').click(function(){
		$('#hidden_update_buttons').hide(200, function(){
			$('#show_update_post_buttons').show(200);
		});
	});
	
	//register
	$("#submit-form").click(function(e){

		var formData = new FormData($("#data")[0]);
		
		$.ajax({
			url: base_url+'/'+document.getElementById('post_url').value,
			type: 'POST',
			data: formData,
			async: false,
			success: function(data){
					$('#stage').hide('fast');
					var stage = document.getElementById('result-stage');
					stage.innerHTML = data;
					$('#result-stage').show(function(){
						var signal = document.getElementById('success_signal').value;
						if(signal='success'){
							$('#data').hide();
						}
					});
			},
			cache: false,
			contentType: false,
			processData: false
		});

		return false;
	});
	
	//login
	$("#login").click(function(e){
		var username = document.getElementById("username").value;
		var password = document.getElementById("password").value;
		if(username === "" && password === ""){
			return;
		}else{
			$.ajax({
				type: "post",
				url: base_url+"/login",
				data: "username="+username+"&password="+password,
				success: function(data){
					var stage = document.getElementById('result-stage');
					stage.innerHTML = data;
					$('#result-stage').hide('fast',function(){
						$('#result-stage').show('slow',function(){
							$('.form-group').hide('slow');
						});
					});
				}
			});
		}
	});
	
	//dashboard
	$('.show_delete').click(function(){
		$(this).hide('slow', function(){
			$(this).prevAll('span').fadeIn('slow');		
		});
	});
	
	$('.cancel_delete').click(function(){
		$(this).parent('span').fadeOut(function(){
			$(this).nextAll('.show_delete').fadeIn('slow');
		});
	});
	
	$(".confirm_delete").click(function(e){
		$url = this.getAttribute('data');
		var child = this;
		$.ajax({
			context:this,
			type: "post",
			url: $url,
			success: function(data){
				var stage = document.getElementById('result-stage');
				stage.innerHTML = data;
				$('.result-stage').hide('fast',function(){
					$('.result-stage').show('slow', function(){
						$(child).closest('tr').remove();
					});
				});
			}
		});
	});
	
	//20161002
	//Start: Update generated task status functions
	
		$(".show_update_generated_task_status_modal").click(function(){
			//get the chosen record's generated_task_id and save it to a variable
			var generated_task_id = this.getAttribute('data-generated-task-id');
			
			//update the confirm_generated_task_update button's data-generated-task-id attr value
			$(".confirm_generated_task_update").attr("data-generated-task-id", generated_task_id);
		});
		
		$(".update_generated_task_status").click(function(){
			//get the chosen update_type value
			var update_type = this.getAttribute("data-update-type");
			
			//update the confirm_generated_task_update button's data-update-type attribute value
			$(".confirm_generated_task_update").attr("data-update-type", update_type);
			
			//show the confirmation buttons into the modal
			$("#UpdateTaskStatusModalInitialContent").hide();
			$("#UpdateTaskStatusModalConfirmationContent").show();
		});
		
		$(".cancel-generated-task-status-update").click(function(){
			//set the modal's state to its default state
			default_update_generated_task_status_modal_state();
		});
		
		$(".confirm_generated_task_update").click(function(){
			//get and save the data-generated-task-id and data-update-type attributes of the current button into variables
			var generated_task_id = this.getAttribute("data-generated-task-id");
			var update_type = this.getAttribute("data-update-type");
			
			//use the saved variables and send them into the controller using AJAX for processing
			//check if the variables are well defined
			if(generated_task_id === "" || update_type === ""){
			//if the variables are not properly defined, alert the user and return false.
				alert("Undefined variables.");
				return;
			}else{
			//if the variables are well defined and are ready for server processing.
				$.ajax({
					type: "post",
					url: base_url+"/admin/update-task-status",
					data: "generated_task_id="+generated_task_id+"&update_type="+update_type,
					success: function(data){
						if(data == 'success'){
						//if the server returned a "success" message.
							$("#UpdateTaskStatusModalConfirmationContent").hide();
							$("#UpdateTaskStatusResultSuccess").show();
						}else{
						//if the server did not return a "success" message.
							$("#UpdateTaskStatusModalConfirmationContent").hide();
							$("#UpdateTaskStatusResultFail").show();
						}
						setTimeout(function(){
							var url	= window.location.href; 
							window.location.replace(url);
						},2000);
					}
				});
			}
		});
		
		function default_update_generated_task_status_modal_state(){
			//set confirm_generated_task_update button's data-generated-task-id and data-update-type attribute values to none
			$(".confirm_generated_task_update").attr("data-generated-task-id", "none");
			$(".confirm_generated_task_update").attr("data-update-type", "none");
			
			//show the #UpdateTaskStatusModalInitialContent div element and hide the #UpdateTaskStatusModalConfirmationContent div element
			$("#UpdateTaskStatusModalInitialContent").show();
			$("#UpdateTaskStatusModalConfirmationContent").hide();
		}
	
	//End: Update generated task status functions
});