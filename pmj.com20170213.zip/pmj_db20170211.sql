-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 11, 2017 at 07:54 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pmj_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `45cms_appearance`
--

CREATE TABLE IF NOT EXISTS `45cms_appearance` (
  `appearance_id` int(11) NOT NULL AUTO_INCREMENT,
  `appearance_name` text NOT NULL,
  `body_font_family` text NOT NULL,
  `body_background_color` text NOT NULL,
  `body_maximum_width` text NOT NULL,
  `body_font_size` text NOT NULL,
  `header_background_color` text NOT NULL,
  `header_header_text_color` text NOT NULL,
  `header_normal_text_color` text NOT NULL,
  `header_link_text_color` text NOT NULL,
  `article_background_color` text NOT NULL,
  `article_header_text_color` text NOT NULL,
  `article_normal_text_color` text NOT NULL,
  `article_link_text_color` text NOT NULL,
  `footer_background_color` text NOT NULL,
  `footer_header_text_color` text NOT NULL,
  `footer_normal_text_color` text NOT NULL,
  `footer_link_text_color` text NOT NULL,
  PRIMARY KEY (`appearance_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `45cms_appearance`
--

INSERT INTO `45cms_appearance` (`appearance_id`, `appearance_name`, `body_font_family`, `body_background_color`, `body_maximum_width`, `body_font_size`, `header_background_color`, `header_header_text_color`, `header_normal_text_color`, `header_link_text_color`, `article_background_color`, `article_header_text_color`, `article_normal_text_color`, `article_link_text_color`, `footer_background_color`, `footer_header_text_color`, `footer_normal_text_color`, `footer_link_text_color`) VALUES
(1, 'default', 'Tahoma, Geneva, sans-serif', '#666666', '950px', '16px', 'crimson', '#ffffff', '#ffffff', '#ffffff', '#ffffff', '#333333', '#666666', '#000000', '#0066cc', '#ffffff', '#ffffff', '#ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `45cms_posts`
--

CREATE TABLE IF NOT EXISTS `45cms_posts` (
  `url` text,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` text NOT NULL,
  `author` text NOT NULL,
  `image_url` text,
  `content` text NOT NULL,
  `views` int(11) DEFAULT NULL,
  `labels` text,
  `title` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=308 ;

--
-- Dumping data for table `45cms_posts`
--

INSERT INTO `45cms_posts` (`url`, `id`, `author_id`, `team_id`, `date`, `type`, `author`, `image_url`, `content`, `views`, `labels`, `title`) VALUES
('riverside_infotech_11', 194, 1, 0, '2017-02-09 06:36:41', 'Normal', 'admin', '0', 'Riverside Infotech', 109, 'type_team', 'Riverside Infotech'),
('counter_101_1', 225, 1, 194, '2017-02-10 05:40:16', 'Normal', 'admin', '0', 'Counter 101', NULL, 'type_unit, department_pos', 'Counter 101'),
('counter_102_2', 226, 1, 194, '2017-02-10 05:40:24', 'Normal', 'admin', '0', 'Counter 102', NULL, 'type_unit, department_pos', 'Counter 102'),
('counter_103_3', 227, 1, 194, '2017-02-10 05:40:32', 'Normal', 'admin', '0', 'Counter 103', NULL, 'type_unit, department_pos', 'Counter 103'),
('counter_104_4', 228, 1, 194, '2017-02-10 05:46:10', 'Normal', 'admin', '0', 'Counter 104', NULL, 'type_unit, department_pos', 'Counter 104'),
('counter_105_5', 229, 1, 194, '2017-02-10 05:46:58', 'Normal', 'admin', '0', 'Counter 105', NULL, 'type_unit, department_pos', 'Counter 105'),
('counter_106_6', 230, 1, 194, '2017-02-10 05:47:06', 'Normal', 'admin', '0', 'Counter 106', NULL, 'type_unit, department_pos', 'Counter 106'),
('counter_107_7', 231, 1, 194, '2017-02-10 05:47:50', 'Normal', 'admin', '0', 'Counter 107', NULL, 'type_unit, department_pos', 'Counter 107'),
('counter_108_8', 232, 1, 194, '2017-02-10 05:48:11', 'Normal', 'admin', '0', 'Counter 108', NULL, 'type_unit, department_pos', 'Counter 108'),
('counter_109_9', 233, 1, 194, '2017-02-10 05:48:22', 'Normal', 'admin', '0', 'Counter 109', NULL, 'type_unit, department_pos', 'Counter 109'),
('counter_110_10', 234, 1, 194, '2017-02-10 05:48:28', 'Normal', 'admin', '0', 'Counter 110', NULL, 'type_unit, department_pos', 'Counter 110'),
('counter_111_11', 235, 1, 194, '2017-02-10 05:48:30', 'Normal', 'admin', '0', 'Counter 111', NULL, 'type_unit, department_pos', 'Counter 111'),
('counter_112_12', 236, 1, 194, '2017-02-10 05:48:33', 'Normal', 'admin', '0', 'Counter 112', NULL, 'type_unit, department_pos', 'Counter 112'),
('counter_113_13', 237, 1, 194, '2017-02-10 05:48:35', 'Normal', 'admin', '0', 'Counter 113', NULL, 'type_unit, department_pos', 'Counter 113'),
('counter_114_14', 238, 1, 194, '2017-02-10 05:48:37', 'Normal', 'admin', '0', 'Counter 114', NULL, 'type_unit, department_pos', 'Counter 114'),
('counter_115_15', 239, 1, 194, '2017-02-10 05:48:40', 'Normal', 'admin', '0', 'Counter 115', NULL, 'type_unit, department_pos', 'Counter 115'),
('counter_116_16', 240, 1, 194, '2017-02-10 05:48:42', 'Normal', 'admin', '0', 'Counter 116', NULL, 'type_unit, department_pos', 'Counter 116'),
('counter_117_17', 241, 1, 194, '2017-02-10 05:48:44', 'Normal', 'admin', '0', 'Counter 117', NULL, 'type_unit, department_pos', 'Counter 117'),
('counter_118_18', 242, 1, 194, '2017-02-10 05:48:48', 'Normal', 'admin', '0', 'Counter 118', NULL, 'type_unit, department_pos', 'Counter 118'),
('counter_119_19', 243, 1, 194, '2017-02-10 05:48:51', 'Normal', 'admin', '0', 'Counter 119', NULL, 'type_unit, department_pos', 'Counter 119'),
('counter_120_20', 244, 1, 194, '2017-02-10 05:48:56', 'Normal', 'admin', '0', 'Counter 120', NULL, 'type_unit, department_pos', 'Counter 120'),
('counter_121_21', 245, 1, 194, '2017-02-10 05:48:58', 'Normal', 'admin', '0', 'Counter 121', NULL, 'type_unit, department_pos', 'Counter 121'),
('counter_128_22', 246, 1, 194, '2017-02-10 05:49:02', 'Normal', 'admin', '0', 'Counter 128', NULL, 'type_unit, department_pos', 'Counter 128'),
('counter_129_23', 247, 1, 194, '2017-02-10 05:49:04', 'Normal', 'admin', '0', 'Counter 129', NULL, 'type_unit, department_pos', 'Counter 129'),
('counter_130_24', 248, 1, 194, '2017-02-10 05:49:11', 'Normal', 'admin', '0', 'Counter 130', NULL, 'type_unit, department_pos', 'Counter 130'),
('counter_133_25', 249, 1, 194, '2017-02-10 05:49:13', 'Normal', 'admin', '0', 'Counter 133', NULL, 'type_unit, department_pos', 'Counter 133'),
('counter_134_26', 250, 1, 194, '2017-02-10 05:49:16', 'Normal', 'admin', '0', 'Counter 134', NULL, 'type_unit, department_pos', 'Counter 134'),
('counter_135_27', 251, 1, 194, '2017-02-10 05:49:20', 'Normal', 'admin', '0', 'Counter 135', NULL, 'type_unit, department_pos', 'Counter 135'),
('counter_137_28', 252, 1, 194, '2017-02-10 05:49:22', 'Normal', 'admin', '0', 'Counter 137', NULL, 'type_unit, department_pos', 'Counter 137'),
('counter_139_29', 253, 1, 194, '2017-02-10 05:49:29', 'Normal', 'admin', '0', 'Counter 139', NULL, 'type_unit, department_pos', 'Counter 139'),
('counter_140_30', 254, 1, 194, '2017-02-10 05:49:33', 'Normal', 'admin', '0', 'Counter 140', NULL, 'type_unit, department_pos', 'Counter 140'),
('counter_141_31', 255, 1, 194, '2017-02-10 05:49:35', 'Normal', 'admin', '0', 'Counter 141', NULL, 'type_unit, department_pos', 'Counter 141'),
('counter_142_32', 256, 1, 194, '2017-02-10 05:49:37', 'Normal', 'admin', '0', 'Counter 142', NULL, 'type_unit, department_pos', 'Counter 142'),
('counter_143_33', 257, 1, 194, '2017-02-10 05:49:39', 'Normal', 'admin', '0', 'Counter 143', NULL, 'type_unit, department_pos', 'Counter 143'),
('counter_144_34', 258, 1, 194, '2017-02-10 05:49:42', 'Normal', 'admin', '0', 'Counter 144', NULL, 'type_unit, department_pos', 'Counter 144'),
('counter_145_35', 259, 1, 194, '2017-02-10 05:49:45', 'Normal', 'admin', '0', 'Counter 145', NULL, 'type_unit, department_pos', 'Counter 145'),
('counter_146_36', 260, 1, 194, '2017-02-10 05:49:47', 'Normal', 'admin', '0', 'Counter 146', NULL, 'type_unit, department_pos', 'Counter 146'),
('counter_148_37', 261, 1, 194, '2017-02-10 05:49:51', 'Normal', 'admin', '0', 'Counter 148', NULL, 'type_unit, department_pos', 'Counter 148'),
('counter_149_38', 262, 1, 194, '2017-02-10 05:49:56', 'Normal', 'admin', '0', 'Counter 149', NULL, 'type_unit, department_pos', 'Counter 149'),
('counter_150_39', 263, 1, 194, '2017-02-10 05:49:59', 'Normal', 'admin', '0', 'Counter 150', NULL, 'type_unit, department_pos', 'Counter 150'),
('counter_151_40', 264, 1, 194, '2017-02-10 05:50:02', 'Normal', 'admin', '0', 'Counter 151', NULL, 'type_unit, department_pos', 'Counter 151'),
('counter_153_41', 265, 1, 194, '2017-02-10 05:50:05', 'Normal', 'admin', '0', 'Counter 153', NULL, 'type_unit, department_pos', 'Counter 153'),
('counter_154_42', 266, 1, 194, '2017-02-10 05:50:09', 'Normal', 'admin', '0', 'Counter 154', NULL, 'type_unit, department_pos', 'Counter 154'),
('counter_155_43', 267, 1, 194, '2017-02-10 05:50:11', 'Normal', 'admin', '0', 'Counter 155', NULL, 'type_unit, department_pos', 'Counter 155'),
('counter_156_44', 268, 1, 194, '2017-02-10 05:50:14', 'Normal', 'admin', '0', 'Counter 156', NULL, 'type_unit, department_pos', 'Counter 156'),
('counter_158_45', 269, 1, 194, '2017-02-10 05:50:17', 'Normal', 'admin', '0', 'Counter 158', NULL, 'type_unit, department_pos', 'Counter 158'),
('counter_159_46', 270, 1, 194, '2017-02-10 05:51:00', 'Normal', 'admin', '0', 'Counter 159', NULL, 'type_unit, department_pos', 'Counter 159'),
('counter_161_47', 271, 1, 194, '2017-02-10 05:51:05', 'Normal', 'admin', '0', 'Counter 161', NULL, 'type_unit, department_pos', 'Counter 161'),
('counter_162_48', 272, 1, 194, '2017-02-10 05:51:07', 'Normal', 'admin', '0', 'Counter 162', NULL, 'type_unit, department_pos', 'Counter 162'),
('counter_163_49', 273, 1, 194, '2017-02-10 05:51:15', 'Normal', 'admin', '0', 'Counter 163', NULL, 'type_unit, department_pos', 'Counter 163'),
('counter_164_50', 274, 1, 194, '2017-02-10 05:51:18', 'Normal', 'admin', '0', 'Counter 164', NULL, 'type_unit, department_pos', 'Counter 164'),
('update_frontview_version_20_51', 275, 1, 194, '2017-02-10 05:52:08', 'Normal', 'admin', '0', 'pos', 2, 'type_task, department_pos', 'Update: Frontview Version 2.0'),
('maintenance_compact_repair_databases_feb_2017_52', 276, 1, 194, '2017-02-10 05:58:21', 'Normal', 'admin', '0', 'pos', 6, 'type_task, department_pos', 'Maintenance: Compact Repair Databases Feb 2017'),
('maintenance_create_files_backups_feb_2017_53', 277, 1, 194, '2017-02-10 06:44:37', 'Normal', 'admin', '0', 'offices', 4, 'type_task, department_offices', 'Maintenance: Create Files Backups Feb 2017'),
('hr1_54', 278, 1, 194, '2017-02-10 06:46:23', 'Normal', 'admin', '0', 'HR1', NULL, 'type_unit, department_offices', 'HR1'),
('hr2_55', 279, 1, 194, '2017-02-10 06:46:30', 'Normal', 'admin', '0', 'HR2', NULL, 'type_unit, department_offices', 'HR2'),
('hr3_56', 280, 1, 194, '2017-02-10 06:46:34', 'Normal', 'admin', '0', 'HR3', NULL, 'type_unit, department_offices', 'HR3'),
('hr4_57', 281, 1, 194, '2017-02-10 06:46:37', 'Normal', 'admin', '0', 'HR4', NULL, 'type_unit, department_offices', 'HR4'),
('acctg1_58', 282, 1, 194, '2017-02-10 06:46:48', 'Normal', 'admin', '0', 'ACCTG1', NULL, 'type_unit, department_offices', 'ACCTG1'),
('acctg2_59', 283, 1, 194, '2017-02-10 06:46:50', 'Normal', 'admin', '0', 'ACCTG2', NULL, 'type_unit, department_offices', 'ACCTG2'),
('acctg3_60', 284, 1, 194, '2017-02-10 06:46:52', 'Normal', 'admin', '0', 'ACCTG3', NULL, 'type_unit, department_offices', 'ACCTG3'),
('acctg4_61', 285, 1, 194, '2017-02-10 06:46:55', 'Normal', 'admin', '0', 'ACCTG4', NULL, 'type_unit, department_offices', 'ACCTG4'),
('acctg5_62', 286, 1, 194, '2017-02-10 06:46:57', 'Normal', 'admin', '0', 'ACCTG5', NULL, 'type_unit, department_offices', 'ACCTG5'),
('leasing1_63', 287, 1, 194, '2017-02-10 06:47:07', 'Normal', 'admin', '0', 'LEASING1', NULL, 'type_unit, department_offices', 'LEASING1'),
('om1_64', 288, 1, 194, '2017-02-10 06:47:17', 'Normal', 'admin', '0', 'OM1', NULL, 'type_unit, department_offices', 'OM1'),
('om2_65', 289, 1, 194, '2017-02-10 06:47:20', 'Normal', 'admin', '0', 'OM2', NULL, 'type_unit, department_offices', 'OM2'),
('edp1_66', 290, 1, 194, '2017-02-10 06:47:30', 'Normal', 'admin', '0', 'EDP1', NULL, 'type_unit, department_offices', 'EDP1'),
('edp2_67', 291, 1, 194, '2017-02-10 06:47:32', 'Normal', 'admin', '0', 'EDP2', NULL, 'type_unit, department_offices', 'EDP2'),
('edp3_68', 292, 1, 194, '2017-02-10 06:47:35', 'Normal', 'admin', '0', 'EDP3', NULL, 'type_unit, department_offices', 'EDP3'),
('edp4_69', 293, 1, 194, '2017-02-10 06:47:38', 'Normal', 'admin', '0', 'EDP4', NULL, 'type_unit, department_offices', 'EDP4'),
('pricing1_70', 294, 1, 194, '2017-02-10 06:47:48', 'Normal', 'admin', '0', 'PRICING1', NULL, 'type_unit, department_offices', 'PRICING1'),
('pricing2_71', 295, 1, 194, '2017-02-10 06:47:49', 'Normal', 'admin', '0', 'PRICING2', NULL, 'type_unit, department_offices', 'PRICING2'),
('bo1_72', 296, 1, 194, '2017-02-10 06:47:56', 'Normal', 'admin', '0', 'BO1', NULL, 'type_unit, department_offices', 'BO1'),
('spmt_bodega_73', 297, 1, 194, '2017-02-10 06:48:32', 'Normal', 'admin', '0', 'SPMT BODEGA', NULL, 'type_unit, department_offices', 'SPMT BODEGA'),
('purchasing1_74', 298, 1, 194, '2017-02-10 06:48:41', 'Normal', 'admin', '0', 'PURCHASING1', NULL, 'type_unit, department_offices', 'PURCHASING1'),
('purchasing2_75', 299, 1, 194, '2017-02-10 06:48:43', 'Normal', 'admin', '0', 'PURCHASING2', NULL, 'type_unit, department_offices', 'PURCHASING2'),
('purchasing3_76', 300, 1, 194, '2017-02-10 06:48:46', 'Normal', 'admin', '0', 'PURCHASING3', NULL, 'type_unit, department_offices', 'PURCHASING3'),
('verifier1_77', 301, 1, 194, '2017-02-10 06:48:49', 'Normal', 'admin', '0', 'VERIFIER1', NULL, 'type_unit, department_offices', 'VERIFIER1'),
('receiving1_78', 302, 1, 194, '2017-02-10 06:48:58', 'Normal', 'admin', '0', 'RECEIVING1', NULL, 'type_unit, department_offices', 'RECEIVING1'),
('receiving2_79', 303, 1, 194, '2017-02-10 06:49:00', 'Normal', 'admin', '0', 'RECEIVING2', NULL, 'type_unit, department_offices', 'RECEIVING2'),
('credit1_80', 304, 1, 194, '2017-02-10 06:49:12', 'Normal', 'admin', '0', 'CREDIT1', NULL, 'type_unit, department_offices', 'CREDIT1'),
('credit2_81', 305, 1, 194, '2017-02-10 06:49:14', 'Normal', 'admin', '0', 'CREDIT2', NULL, 'type_unit, department_offices', 'CREDIT2'),
('credit3_82', 306, 1, 194, '2017-02-10 06:49:15', 'Normal', 'admin', '0', 'CREDIT3', NULL, 'type_unit, department_offices', 'CREDIT3');

-- --------------------------------------------------------

--
-- Table structure for table `45cms_settings`
--

CREATE TABLE IF NOT EXISTS `45cms_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  PRIMARY KEY (`setting_id`,`setting_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `45cms_settings`
--

INSERT INTO `45cms_settings` (`setting_id`, `setting_name`, `setting_value`) VALUES
(1, 'web_app_name', 'Riverside PMJ');

-- --------------------------------------------------------

--
-- Table structure for table `45cms_users`
--

CREATE TABLE IF NOT EXISTS `45cms_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `user_type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`,`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `45cms_users`
--

INSERT INTO `45cms_users` (`id`, `username`, `password`, `date`, `name`, `email`, `user_type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2016-09-03 05:54:17', 'admin', 'admin@admin.com', 'admin'),
(15, 'james', '5e0bdcbddccca4d66d74ba8c1cee1a68', '2017-02-03 01:56:32', 'james', 'none@none.com', ''),
(16, 'rhalp', '5e0bdcbddccca4d66d74ba8c1cee1a68', '2017-02-03 01:56:38', 'rhalp', 'none@none.com', ''),
(17, 'isagani', '5e0bdcbddccca4d66d74ba8c1cee1a68', '2017-02-03 01:57:12', 'isagani', 'none@none.com', ''),
(18, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '2017-02-11 07:49:13', 'user', 'user@user.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `pmj_generated_tasks`
--

CREATE TABLE IF NOT EXISTS `pmj_generated_tasks` (
  `generated_task_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `task_id_unit_id` varchar(50) DEFAULT NULL,
  `date_generated` date NOT NULL,
  `date_updated` date NOT NULL,
  `updater_user_id` int(11) DEFAULT NULL,
  `updater_username` varchar(50) NOT NULL,
  `task_status` varchar(20) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`generated_task_id`),
  UNIQUE KEY `task_id_unit_id` (`task_id_unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=960 ;

--
-- Dumping data for table `pmj_generated_tasks`
--

INSERT INTO `pmj_generated_tasks` (`generated_task_id`, `team_id`, `task_id`, `unit_id`, `task_id_unit_id`, `date_generated`, `date_updated`, `updater_user_id`, `updater_username`, `task_status`) VALUES
(831, 194, 275, 274, '275274', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(832, 194, 275, 273, '275273', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(833, 194, 275, 272, '275272', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(834, 194, 275, 271, '275271', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(835, 194, 275, 270, '275270', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(836, 194, 275, 269, '275269', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(837, 194, 275, 268, '275268', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(838, 194, 275, 267, '275267', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(839, 194, 275, 266, '275266', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(840, 194, 275, 265, '275265', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(841, 194, 275, 264, '275264', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(842, 194, 275, 263, '275263', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(843, 194, 275, 262, '275262', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(844, 194, 275, 261, '275261', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(845, 194, 275, 260, '275260', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(846, 194, 275, 259, '275259', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(847, 194, 275, 258, '275258', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(848, 194, 275, 257, '275257', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(849, 194, 275, 256, '275256', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(850, 194, 275, 255, '275255', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(851, 194, 275, 254, '275254', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(852, 194, 275, 253, '275253', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(853, 194, 275, 252, '275252', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(854, 194, 275, 251, '275251', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(855, 194, 275, 250, '275250', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(856, 194, 275, 249, '275249', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(857, 194, 275, 248, '275248', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(858, 194, 275, 247, '275247', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(859, 194, 275, 246, '275246', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(860, 194, 275, 245, '275245', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(861, 194, 275, 244, '275244', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(862, 194, 275, 243, '275243', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(863, 194, 275, 242, '275242', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(864, 194, 275, 241, '275241', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(865, 194, 275, 240, '275240', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(866, 194, 275, 239, '275239', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(867, 194, 275, 238, '275238', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(868, 194, 275, 237, '275237', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(869, 194, 275, 236, '275236', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(870, 194, 275, 235, '275235', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(871, 194, 275, 234, '275234', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(872, 194, 275, 233, '275233', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(873, 194, 275, 232, '275232', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(874, 194, 275, 231, '275231', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(875, 194, 275, 230, '275230', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(876, 194, 275, 229, '275229', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(877, 194, 275, 228, '275228', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(878, 194, 275, 227, '275227', '2017-02-10', '2017-02-10', NULL, 'admin', 'Pending'),
(879, 194, 275, 226, '275226', '2017-02-10', '2017-02-10', NULL, 'admin', 'Pending'),
(880, 194, 275, 225, '275225', '2017-02-10', '2017-02-10', NULL, 'admin', 'Pending'),
(881, 194, 276, 274, '276274', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(882, 194, 276, 273, '276273', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(883, 194, 276, 272, '276272', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(884, 194, 276, 271, '276271', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(885, 194, 276, 270, '276270', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(886, 194, 276, 269, '276269', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(887, 194, 276, 268, '276268', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(888, 194, 276, 267, '276267', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(889, 194, 276, 266, '276266', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(890, 194, 276, 265, '276265', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(891, 194, 276, 264, '276264', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(892, 194, 276, 263, '276263', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(893, 194, 276, 262, '276262', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(894, 194, 276, 261, '276261', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(895, 194, 276, 260, '276260', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(896, 194, 276, 259, '276259', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(897, 194, 276, 258, '276258', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(898, 194, 276, 257, '276257', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(899, 194, 276, 256, '276256', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(900, 194, 276, 255, '276255', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(901, 194, 276, 254, '276254', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(902, 194, 276, 253, '276253', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(903, 194, 276, 252, '276252', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(904, 194, 276, 251, '276251', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(905, 194, 276, 250, '276250', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(906, 194, 276, 249, '276249', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(907, 194, 276, 248, '276248', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(908, 194, 276, 247, '276247', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(909, 194, 276, 246, '276246', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(910, 194, 276, 245, '276245', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(911, 194, 276, 244, '276244', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(912, 194, 276, 243, '276243', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(913, 194, 276, 242, '276242', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(914, 194, 276, 241, '276241', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(915, 194, 276, 240, '276240', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(916, 194, 276, 239, '276239', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(917, 194, 276, 238, '276238', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(918, 194, 276, 237, '276237', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(919, 194, 276, 236, '276236', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(920, 194, 276, 235, '276235', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(921, 194, 276, 234, '276234', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(922, 194, 276, 233, '276233', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(923, 194, 276, 232, '276232', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(924, 194, 276, 231, '276231', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(925, 194, 276, 230, '276230', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(926, 194, 276, 229, '276229', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(927, 194, 276, 228, '276228', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(928, 194, 276, 227, '276227', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(929, 194, 276, 226, '276226', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(930, 194, 276, 225, '276225', '2017-02-10', '2017-02-10', NULL, 'admin', 'Pending'),
(931, 194, 277, 306, '277306', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(932, 194, 277, 305, '277305', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(933, 194, 277, 304, '277304', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(934, 194, 277, 303, '277303', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(935, 194, 277, 302, '277302', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(936, 194, 277, 301, '277301', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(937, 194, 277, 300, '277300', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(938, 194, 277, 299, '277299', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(939, 194, 277, 298, '277298', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(940, 194, 277, 297, '277297', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(941, 194, 277, 296, '277296', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(942, 194, 277, 295, '277295', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(943, 194, 277, 294, '277294', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(944, 194, 277, 293, '277293', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(945, 194, 277, 292, '277292', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(946, 194, 277, 291, '277291', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(947, 194, 277, 290, '277290', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(948, 194, 277, 289, '277289', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(949, 194, 277, 288, '277288', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(950, 194, 277, 287, '277287', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(951, 194, 277, 286, '277286', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(952, 194, 277, 285, '277285', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(953, 194, 277, 284, '277284', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(954, 194, 277, 283, '277283', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(955, 194, 277, 282, '277282', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(956, 194, 277, 281, '277281', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(957, 194, 277, 280, '277280', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(958, 194, 277, 279, '277279', '2017-02-10', '2017-02-10', NULL, '', 'Pending'),
(959, 194, 277, 278, '277278', '2017-02-10', '2017-02-10', NULL, '', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `team_relations`
--

CREATE TABLE IF NOT EXISTS `team_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `team_creator_id` int(11) NOT NULL,
  `join_requestor_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `team_relations`
--

INSERT INTO `team_relations` (`id`, `team_id`, `team_creator_id`, `join_requestor_id`, `status`) VALUES
(1, 194, 1, 17, 1),
(2, 195, 17, 17, 1),
(3, 187, 17, 17, 0),
(4, 174, 1, 17, 0),
(5, 173, 1, 17, 0),
(6, 195, 17, 15, 1),
(7, 195, 17, 16, 1),
(8, 194, 1, 15, 1),
(9, 216, 15, 15, 1),
(10, 194, 1, 16, 1),
(11, 194, 1, 1, 0),
(12, 307, 18, 18, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
