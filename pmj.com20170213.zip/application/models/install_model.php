<?php
 class Install_model extends CI_Model{
	public function __construct(){
		$this->load->database();
		$this->load->helper('url');
	}

	public function start_install_old(){
		$database_name = $this->input->post('database_name');
		$host_name = $this->input->post('host_name');
		$user_name = $this->input->post('user_name');
		$password = $this->input->post('password');
		
		//dont display PHP errors
		error_reporting(0);
		ini_set('display_errors', 0);
		
		$conn = $this->connect($host_name, $user_name, $password);
		if($conn){
			if($this->create_database($database_name, $conn)){
				if($this->create_table($database_name, $conn)){
					mysql_close($conn);
					return true;
				}
			}
		}
		
		return false;
	}
	
	public function start_install(){
		$database_name = $this->input->post('database_name');
		$host_name = $this->input->post('host_name');
		$user_name = $this->input->post('user_name');
		$password = $this->input->post('password');
		
		//dont display PHP errors
		error_reporting(0);
		ini_set('display_errors', 0);
		
		$conn = $this->connect($host_name, $user_name, $password);
		if($conn){
			if($this->create_table($database_name, $conn)){
				mysql_close($conn);
				return true;
			}
		}
		
		return false;
	}
	
	public function connect($host_name, $user_name, $password){
		$conn = mysql_connect($host_name, $user_name, $password);
		if(! $conn && mysql_error())
		{
			die('Could not connect: 31' . mysql_error());
		}
		
		return $conn;
	}
	
	public function create_database($database_name, $conn){
		$sql = 'CREATE Database '.$database_name.'';
		if(mysql_query($sql, $conn)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function create_table($database_name, $conn){
	
		//20151228 start
		// Add create 45cms_settings table
		// where the main settings of the website will be stored
		// such as website name.
		
		$sql =	'CREATE TABLE 45cms_settings('.
				'setting_id INT NOT NULL AUTO_INCREMENT,'.
				'setting_name VARCHAR(50) NOT NULL,'.
				'setting_value TEXT NOT NULL,'.
				'primary key (setting_id, setting_name))';
		
		
		//execute the query
		mysql_select_db($database_name);
		$retval = mysql_query($sql, $conn);
		if(! $retval)
		{
			die('Could not create table: 45cms_settings' . mysql_error());
		}else{
		// If the query ran successfully, execute the code below.
		// Insert default values to the 45cms_settings table.
			$data = array(
				'setting_name' => 'web_app_name',
				'setting_value'	=> $this->input->post('webapp_name')
			);
			$this->db->insert('45cms_SETTINGS', $data);
		}
		
		//20151228 end
	
		$sql = 	'CREATE TABLE 45cms_posts('.
				'url TEXT,'.
				'id INT NOT NULL AUTO_INCREMENT,'.
				'date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,'.
				'type TEXT NOT NULL,'.
				'author TEXT NOT NULL,'.
				'image_url TEXT,'.
				'content TEXT NOT NULL,'.
				'views INT,'.
				'labels TEXT,'.
				'title TEXT,'.
				'primary key (id))';
		
		mysql_select_db($database_name);
		$retval = mysql_query($sql, $conn);
		if(! $retval )
		{
		  die('Could not create table: 65' . mysql_error());
		}
		
		$sql = 	'CREATE TABLE 45cms_users('.
				'id INT NOT NULL AUTO_INCREMENT,'.
				'username VARCHAR(20) NOT NULL UNIQUE,'.
				'password VARCHAR(50) NOT NULL,'.
				'date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,'.
				'name TEXT NOT NULL,'.
				'email TEXT NOT NULL,'.
				'primary key (id, username))';
		
		mysql_select_db($database_name);
		$retval = mysql_query($sql, $conn);
		if(! $retval )
		{
		  die('Could not create table: 65' . mysql_error());
		}
		
		$sql = 	'CREATE TABLE 45cms_appearance('.
				'appearance_id INT NOT NULL AUTO_INCREMENT,'.
				'appearance_name text NOT NULL,'.
				'body_font_family text NOT NULL,'.
				'body_background_color text NOT NULL,'.
				'body_maximum_width text NOT NULL,'.
				'body_font_size text NOT NULL,'.
				'header_background_color text NOT NULL,'.
				'header_header_text_color text NOT NULL,'.
				'header_normal_text_color text NOT NULL,'.
				'header_link_text_color text NOT NULL,'.
				'article_background_color text NOT NULL,'.
				'article_header_text_color text NOT NULL,'.
				'article_normal_text_color text NOT NULL,'.
				'article_link_text_color text NOT NULL,'.
				'footer_background_color text NOT NULL,'.
				'footer_header_text_color text NOT NULL,'.
				'footer_normal_text_color text NOT NULL,'.
				'footer_link_text_color text NOT NULL,'.
				'primary key (appearance_id))';
		
		mysql_select_db($database_name);
		$retval = mysql_query($sql, $conn);
		if(! $retval )
		{
		  die('Could not create table: 65' . mysql_error());
		}
		
		//insert default appearance values to 45cms_appearance table
		$data = array(
			'body_font_family'			=> 'Tahoma, Geneva, sans-serif',
			'body_font_size'			=> '16',
			'body_background_color'		=> '#cccccc',
			'body_maximum_width'		=> '1024px',
			'header_background_color'	=> '#666666',
			'header_header_text_color'	=> '#ffffff',
			'header_normal_text_color'	=> '#ffffff',
			'header_link_text_color'	=> '#ffffff',
			'article_background_color'	=> '#ffffff',
			'article_header_text_color'	=> '#333333',
			'article_normal_text_color'	=> '#666666',
			'article_link_text_color'	=> '#336633',
			'footer_background_color'	=> '#666666',
			'footer_header_text_color'	=> '#ffffff',
			'footer_normal_text_color'	=> '#ffffff',
			'footer_link_text_color'	=> '#ffffff',
			'appearance_name'			=> 'default'
		);
		$this->db->insert('45cms_appearance', $data);
		
		//make sample page to 45cms_posts table
		$data = array(
			'title' => 'Sample Page',
			'content' => 'This is a sample page',
			'type'	=> 'Featured',
			'labels' => 'sample',
			'url' => 'sample_post_1'
		);
		$this->db->insert('45cms_posts', $data);
		
		//register the administrator account to 45cms_users table
		$admin_username = $this->input->post('admin_username');
		$admin_password = $this->input->post('admin_password');
		$admin_email = $this->input->post('admin_email');
		$admin_name = $this->input->post('admin_name');
		
		$data = array(
			'username' => $admin_username,
			'password' => md5($admin_password),
			'email' => $admin_email,
			'name' => $admin_name
		);
		$this->db->insert('45cms_users', $data);
		
		return true;
	}
	
	public function close(){
		
	}
}