<div class='row post-custom'>
	<?php if(isset($side_bar)){ ?>
		<?php if($post['image_url']){?>
		<div class='col-sm-12 text-center post-image-custom'>
			<a class="fancybox" href='<?php echo base_url().'images/uploads/'.$post['image_url'];?>'><img class='img-responsive' src='<?php echo base_url().'images/uploads/'.$post['image_url'];?>'/></a>
		</div>
			
		<div class='col-sm-12'>
			<h1 class="page-title-custom"><?php echo $post['title']?></h1>
			<p><i><?php echo $post['date'];?></i></p>
		<?php }else{ ?>
			
			<div class='col-sm-12'>
			<h1 class="page-title-custom"><?php echo $post['title']?></h1>
			<p><i><?php echo $post['date'];?></i></p>
		<?php } ?>
			<?php echo $post['content'];?>
		</div>
	<?php }else{ ?>
		<?php if($post['image_url']){?>
		<div class='col-sm-4 text-center post-image-custom'>
			<a class="fancybox" href='<?php echo base_url().'images/uploads/'.$post['image_url'];?>'><img class='img-responsive' src='<?php echo base_url().'images/uploads/'.$post['image_url'];?>'/></a>
		</div>
			
		<div class='col-sm-8'>
			<h1 class="page-title-custom"><?php echo $post['title']?></h1>
			<p><i><?php echo $post['date'];?></i></p>
		<?php }else{ ?>
			
			<div class='col-sm-12'>
			<h1 class="page-title-custom"><?php echo $post['title']?></h1>
			<p><i><?php echo $post['date'];?></i></p>
		<?php } ?>
			<?php echo $post['content'];?>
		</div>
	<?php } ?>
</div>
	
