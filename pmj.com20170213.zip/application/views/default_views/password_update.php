<br/>
<div class="col-sm-12 tex-center">
	<div class="col-sm-3">
	</div>
	<div class="col-sm-6 ">
		<div class="panel panel-success">
			<div class="panel-heading">
				<h2 class="panel-title">Password Update</h2>
			</div>
			<div class="panel-body password_update_form">
				<div class='form-group'>
					<label for='current_password'>Current Password</label>
					<input type='password' class='form-control' name='current_password' id='current_password' placeholder='Type current password here...'>
				</div>
				<div class='form-group'>
					<label for='new_password'>New Password</label>
					<input type='password' class='form-control' name='new_password' id='new_password' placeholder='Type new password here...'>
				</div>
				<div class='form-group'>
					<label for='confirm_new_password'>Confirm New Password</label>
					<input type='password' class='form-control' name='confirm_new_password' id='confirm_new_password' placeholder='Confirm password here...'>
				</div>
				<div class='form-group'>
					<button class='btn btn-success' type='button' id='change_password'>Submit</button>
				</div>
			</div>
			<div class="panel-footer result_stage bg-warning" style="display:none;">
			</div>
		</div>
	</div>
	<div class="col-sm-3">
	</div>
</div>