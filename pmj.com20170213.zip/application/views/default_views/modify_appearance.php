<div class='col-sm-12'>
	<h2>Modify Appearace</h2>
	<small>Admin > Modify Appearance</small>
	
<form id="data" method="post" enctype="multipart/form-data">
	<!--
		Body
			- Font Family
			- Main background color.
			- Website maximum width.
			- Font size
	-->
	<div class='col-sm-12 bg-success'>
		<h3>Body Appearance</h3>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='body_font_family'>Font Family</label>
				<input type='text' class='form-control' name='body_font_family' id='body_font_family' value='<?php echo $style['body_font_family']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='body_font_size'>Font Size</label>
				<input type='text' class='form-control' name='body_font_size' id='body_font_size' value='<?php echo $style['body_font_size']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='forn-group'>
				<label for='body_background_color'>Background Color</label>
				<input type='text' class='form-control' name='body_background_color' id='body_background_color' value='<?php echo $style['body_background_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='body_maximum_width'>Maximum Width</label>
				<input type='text' class='form-control' name='body_maximum_width' id='body_maximum_width' value='<?php echo $style['body_maximum_width']; ?>'/>
			</div>
		</div>
	</div>

	<!--
		header
			- Background color.
			- Header text color.
			- Normal text color.
			- Link	text color.
	-->
	<div class='col-sm-12'>
		<h3>Header Appearance</h3>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='header_background_color'>Backgound Color</label>
				<input type='text' class='form-control' name='header_background_color' id='header_background_color' value='<?php echo $style['header_background_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='header_header_text_color'>Header Text Color</label>
				<input type='text' class='form-control' name='header_header_text_color' id='header_header_text_color' value='<?php echo $style['header_header_text_color']; ?>'/> 
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='header_normal_text_color'>Normal Text Color</label>
				<input type='text' class='form-control' name='header_normal_text_color' id='header_normal_text_color' value='<?php echo $style['header_normal_text_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='header_link_text_color'>Link Text Color</label>
				<input type='text' class='form-control' name='header_link_text_color' id='header_link_text_color' value='<?php echo $style['header_link_text_color']; ?>'/>
			</div>
		</div>
	</div>

	<!--
		Article
			- Background color.
			- Header text color.
			- Normal text color.
			- Link	text color.
	-->
	<div class='col-sm-12 bg-success'>
		<h3>Article Appearance</h3>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='article_background_color'>Background Color</label>
				<input type='text' class='form-control' name='article_background_color' id='article_background_color' value='<?php echo $style['article_background_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='article_header_text_color'>Header Text Color</label>
				<input type='text' class='form-control' name='article_header_text_color' id='article_header_text_color' value='<?php echo $style['article_header_text_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='article_normal_text_color'>Normal Text Color</label>
				<input type='text' class='form-control' name='article_normal_text_color' id='article_normal_text_color' value='<?php echo $style['article_normal_text_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='article_link_text_color'>Link Text Color</label>
				<input type='text' class='form-control' name='article_link_text_color' id='article_link_text_color' value='<?php echo $style['article_link_text_color']; ?>'/>
			</div>
		</div>
	</div>

	<!--
			
		Footer
			- Background color.
			- Header text color.
			- Normal text color.
			- Link	text color.
	-->
	<div class='col-sm-12'>
		<h3>Footer Appearance</h3>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='footer_background_color'>Background Color</label>
				<input type='text' class='form-control' name='footer_background_color' id='footer_background_color' value='<?php echo $style['footer_background_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='footer_header_text_color'>Header Text Color</label>
				<input type='text' class='form-control' name='footer_header_text_color' id='footer_header_text_color' value='<?php echo $style['footer_header_text_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='footer_normal_text_color'>Normal Text Color</label>
				<input type='text' class='form-control' name='footer_normal_text_color' id='footer_normal_text_color' value='<?php echo $style['footer_normal_text_color']; ?>'/>
			</div>
		</div>
		<div class='col-md-6'>
			<div class='form-group'>
				<label for='footer_link_text_color'>Link Text Color</label>
				<input type='text' class='form-control' name='footer_link_text_color' id='footer_link_text_color' value='<?php echo $style['footer_link_text_color']; ?>'/>
			</div>
		</div>
	</div>

	<div class='col-sm-12'>
		<button type='button' class='btn btn-success btn-lg' id='universal_submit' submit-to='<?php echo base_url(); ?>admin/parse/save_appearance_settings'>Update Appearance</button>
	</div>
	<div class='col-sm-12'>
		<div class='result-stage'>
		
		</div>
	</div>
</form>
</div>