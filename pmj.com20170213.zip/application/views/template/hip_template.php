<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta class="og-image" property="og:image" content="" />
    <title><?php 
	
	if(!empty($title)){
		echo $title;
	}elseif(!empty($post['title'])){
		echo $post['title'];
	}
	?> 
	| iLisondra
	</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!--My CSS-->
	<link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/generated_css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/hip_template_style.css" rel="stylesheet">
	
	<!--20170115 Font Awesome-->
	<link rel="stylesheet" href="<?php echo base_url();?>font-awesome-4.7.0/css/font-awesome.min.css">
  </head>
  <body ng-app="app_main" ng-controller="main_controller">
    <div class='container-fluid main-container' >

		<header class='clearfix'>
			<nav class="mobile-navbar-custom hidden-lg hidden-md hidden-sm" style="margin-top:10px;">
				<div class="cols-sm-12">
					<div class="mobile-navbar-button">
						<a href="#" style="padding: 20px;background-color: black;border-radius: 10px;margin-top: 10px;">
							<span class="glyphicon glyphicon-list"></span>
						</a>
					</div>
					<div class="nav-links-wrapper">
					</div>
					<div class="mobile-brand-custom text-center">
					</div>
				</div>
			</nav>
			<nav class="navbar-custom hidden-xs">
				<div class="col-md-2 brand-custom">
					<a href='<?php echo base_url(); ?>'><img class='custom-logo' src="<?php echo base_url(); ?>images/logo.png"/></a>
				</div>
				<div class="col-md-8 navbar-links-custom  hidden-sm hidden-lg hidden-md">
					<ul class='nav navbar-nav navbar-right'>
						<li><a href="<?php echo base_url(); ?>">Home</a></li>
						<li><a href="<?php echo base_url().'download_0'; ?>">Download</a></li>
						<li><a href="<?php echo base_url().'instructions_5'; ?>">Instructions</a></li>
						<li><a href="<?php echo base_url().'about_1'; ?>">About</a></li>
						<?php if($this->session->userdata('user_validated')){?>
						<li><a href='<?php echo base_url().'dashboard';?>'>Dashboard</a></li>
						<li><a href='<?php echo base_url().'logout';?>'>Log Out</a></li>
						<?php }?>
					</ul>
				</div>
				<?php if($this->session->userdata('user_validated')){?>
				<div class="col-md-2 pull-right">
					<a class='btn btn-success btn-xs' href='<?php echo base_url(); ?>logout'>
						<span class='glyphicon glyphicon-off'></span>
						Logout
					</a>
				</div>
				<?php }else{ ?>
				<div class="col-md-2 pull-right">
					<a class='btn btn-success btn-xs' href='<?php echo base_url(); ?>login'>
						<span class='glyphicon glyphicon-lock'></span>
						Login
					</a>
				</div>
				<?php } ?>
			</nav>
		</header>
		
		<div class='clearfix'>
			<div class='col-sm-3 col-md-2 left-bar-nav hidden-xs hidden-md hidden-lg hidden sidebar'>
				<ul class='nav nav-sidebar'>
					<li><a href="<?php echo base_url(); ?>"><span class='glyphicon glyphicon-home'> </span> <span class='sidebar-nav-text'> Home </span></a></li>
					<li><a href="<?php echo base_url().'category/blog'; ?>"><span class='glyphicon glyphicon-pencil'> </span> <span class='sidebar-nav-text'> Blog Posts</span></a></li>
					<li><a href="<?php echo base_url().'portfolio'; ?>"><span class='glyphicon glyphicon-briefcase'> </span> <span class='sidebar-nav-text'> My Portfolio</span></a></li>
					<li><a href="<?php echo base_url().'instructions_5'; ?>"><span class='glyphicon glyphicon-user'>  </span> <span class='sidebar-nav-text'> About Me</span></a></li>
					<li><a href="<?php echo base_url().'about_1'; ?>"><span class='glyphicon glyphicon-phone'> </span> <span class='sidebar-nav-text'> Contact Me</span></a></li>
					<?php if($this->session->userdata('user_validated')){?>
					<li><a href='<?php echo base_url().'dashboard';?>'><span class='glyphicon glyphicon-cog'> </span> <span class='sidebar-nav-text'> Dashboard</span></a></li>
					<li><a href='<?php echo base_url().'logout';?>'><span class='glyphicon glyphicon-off'> </span> <span class='sidebar-nav-text'> Log Out</span></a></li>
					<?php }?>
				</ul>
			</div>
			<div class='col-sm-12 col-md-12'>
				<div class="row">
					<article class='clearfix'>
						
						<?php if(!empty($side_bar)){ ?>
							<div class="col-sm-12 col-md-8 post-sidebar">
								<?php	echo $body; ?>
							</div>
							<div class="col-sm-12 col-md-4">
								<?php	echo $side_bar;?>
							</div>
						<?php }else{ ?>
							<div class="col-sm-12">
								<?php	echo $body; ?>
							</div>
						<?php } ?>
					</article>
				</div>
			</div>
		</div>
		<footer>
			<div class='container-fluid'>
				<div class='col-sm-12 text-right'>
					<small>Copyright© 2017 - All Rights Reserved</small> |
					<a href="http://ilisondra.x10host.com/">
						<span><i>45CMS Codeigniter V1.2 | iLisondra</i></span>
					</a>
				</div>
			</div>
		</footer>
	</div>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
    <script src="<?php echo base_url();?>js/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>js/script.js"></script>
	
	<!--Angular JS Files-->
	<script src="<?php echo base_url();?>js/angular.min.js"></script>
	<script src="<?php echo base_url();?>js/myAngularScript.js"></script>

	
	<!--wysywig-->
	<!-- <script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script> -->
	<script src="<?php echo base_url();?>js/tinymce/tinymce.min.js"></script>
	<script>tinymce.init({selector: "textarea",
    theme: "modern",
    plugins: [
        "advlist autolink lists link print hr anchor",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime nonbreaking save table contextmenu directionality",
        "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "print preview media | forecolor backcolor emoticons",
    image_advtab: true,
    templates: [
        {title: 'Test template 1', content: 'Test 1'},
        {title: 'Test template 2', content: 'Test 2'}
    ]});</script>
  </body>
</html>