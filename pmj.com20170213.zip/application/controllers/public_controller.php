<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Public_controller extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('main_model');
		$this->load->helper('url');
		$this->load->helper('file');
		$this->load->helper('form');
		$this->load->helper('text');
		$this->load->helper('html');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('email');
		$this->load->library('image_lib');
	}
	
	public function install(){
		if($this->main_model->database_connect()){
			echo 'Connected!';
		}else{
			redirect('/install');
		}
	}
	
	public function generated_css(){
		$data['style'] = $this->main_model->get_style('default');
		$this->load->view('default_views/generated_css', $data);
	}
	
	public function index(){
		$data['title'] = 'Home';
		$data['sticky'] = $this->main_model->get_where('type', 'Sticky', 4);
		$data['featured'] = $this->main_model->get_where_order_by('type', 'Featured', 3, 'id', 'ASC');
		$data['works'] = $this->main_model->get_where('type', 'Portfolio', 4);
		$data['posts'] = $this->main_model->get_where('labels', 'blog');
		$data['recent_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'date', 'DESC');
		$data['popular_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'views', 'DESC');
		$data['body'] = $this->load->view('default_views/home', $data, true);
		$this->load_template($data);
	}
	
	public function portfolio(){
		$data['title'] = 'Portfolio of Works';
		$data['works'] = $this->main_model->get_where('labels', 'portfolio');
		$data['body'] = $this->load->view('default_views/portfolio', $data, true);
		$this->load_template($data);
	}
	
	public function read($url){
		$data['brand'] = 'Sample';
		$data['post'] = $this->main_model->get_post($url);
		if($data['post'] == false){
			redirect(base_url().'not_found');
		}
		$data['articles'] = $this->main_model->get_where('labels', 'blog', 10);
		$data['side_bar'] = $this->load->view('template/sidebar', $data, true);
		$data['body'] = $this->load->view('default_views/read', $data, true);
		$this->load_template($data);
	}
	
	/*
		20151228
		Will be used instead of the normal calling of the template:
		ex:
			normal: $this->load->view('template/main_template', $data);
			this:	$this->load_template($data);
		The template to be used will be defined in the load_template function only.
		This is more handy because you can send more variables to the default
		template without calling them each time in each function.
	*/
	public function load_template($data){
		$data['web_app_name'] = $this->main_model->get_setting_value('web_app_name');
		$data['recent_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'date', 'DESC');
		$data['popular_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'views', 'DESC');
		$this->load->view('template/hip_template', $data);
	}
	
	public function login(){
		if(!$this->session->userdata('user_validated')){
			if(!empty($_POST)){
				//came from login form
				$result = $this->main_model->login();
				
				if($result['result'] == true){
					//login success
					$data['title'] = 'Login Success.';
					$data['message'] = 'You have successfully logged in.
						<p>Click on the button bellow to proceed to the dashboard.<br/>
							<a class="btn btn-info" href="'.base_url().'dashboard">Dashboard</a>
						</p>';
					echo 'Hello '.$this->session->userdata('username');
				}else{
					//login failed
					$data['title'] = 'Login Failed.';
					$data['message'] = 'Please check you inputs.';
				}
				$this->load->view('system_message', $data);
			}else{
				//came from login link
				$data['title'] = 'Login';
				$data['body'] = $this->load->view('login', $data, TRUE);
				
				$this->load_template($data);
			}
		}else{
			redirect(base_url().'dashboard');
		}
	}
	
	public function register(){
		$data['title'] = 'Register';

		$data['body'] = $this->load->view('register', $data, true);
		$this->load_template($data);
	}
	
	public function process_register(){
		$result = $this->main_model->register();
		if($result['result']){
			$data['title'] = 'Success';
			$data['message'] = $result['message'];
			$this->load->view('system_message', $data);
		}else{
			$data['title'] = 'Failed';
			$data['message'] = $result['message'];
			$this->load->view('system_message', $data);
		}
	}
	
	public function not_found(){
		$data['title'] = 'Page Not Found';
		$data['articles'] = $this->main_model->get_where('labels', 'blog', 5);
		$data['side_bar'] = $this->load->view('template/sidebar', $data, true);
		$data['body'] = $this->load->view('default_views/page_not_found', $data, true);
		$this->load_template($data);
	}
	
	//===============================================================================
	//==========================	ANGULAR JS FUNCTIONS	============================
	//===============================================================================
	
	public function angular_index(){
		$data['title'] = 'Angular App';
		$data['works'] = $this->main_model->get_where('labels', 'portfolio');
		
		//check if the user is logged in or not.
		if($this->session->userdata('user_validated')){
			//if the user_validated session variable is equal to true
			//show the dashboard
			$data['body'] = $this->load->view('angular/dashboard', $data, true);
		}else{
			//show the login page
			$data['body'] = $this->load->view('angular/login', $data, true);
		}
		$this->load_template($data);
	}
	
	public function angular_register_attempt(){
		//decode the post objects from the angular register application
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		//send the decoded object to the register function in the model
		$result = $this->main_model->register($request);
		
		//if the models register function returned true
		if($result['result'] == TRUE){
			$data['register_result'] = TRUE;
		}else{
			$data['register_result'] = FALSE;
		}
		
		//return the result to the client in JSON format
		echo json_encode($data);
	}
	
	public function angular_login_attempt(){
		//decode the post objects
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		//store the post objects to variables 
		$username = $request->username;
		$password = $request->password;
		
		//use the variables as parameters for the login function in the model 
		//to check if the username and password are valid
		$result = $this->main_model->login($username, $password);
		
		//if the login returned true
		if($result['result'] == TRUE){
			$data['username'] = $username;
			$data['login_result'] = TRUE;
		}else{
			$data['login_result'] = FALSE;
		}
		
		//return the login result to the client in json format
		echo json_encode($data);
	}
}