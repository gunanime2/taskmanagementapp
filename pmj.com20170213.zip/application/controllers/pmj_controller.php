<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pmj_controller extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('main_model');
		$this->load->helper('url');
		$this->load->helper('file');
		$this->load->helper('form');
		$this->load->helper('text');
		$this->load->helper('html');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->library('email');
		$this->load->library('image_lib');
		$this->is_admin();
	}
	
	public function is_admin(){
		if(!$this->session->userdata('username')){
			redirect(base_url().'login');
		}
	}
	
	/*
		20151228
		Will be used instead of the normal calling of the template:
		ex:
			normal: $this->load->view('template/main_template', $data);
			this:	$this->load_template($data);
		The template to be used will be defined in the load_template function only.
		This is more handy because you can send more variables to the default
		template without calling them each time in each function.
	*/
	public function load_template($data){
		$data['web_app_name'] = $this->main_model->get_setting_value('web_app_name');
		$data['recent_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'date', 'DESC');
		$data['popular_posts'] = $this->main_model->get_where_order_by('labels', 'blog', 10, 'views', 'DESC');
		$this->load->view('template/hip_template', $data);
	}
	
	//20161002
	//Receives variables from an AJAX call and uses the data to update a task's status.
	//Returns "success" or "failed" to the javascript AJAX function.
	public function update_task_status($type = FALSE, $task_id = FALSE){
		//save the POST variables that were sent by the AJAX function into PHP variables
		if($type == FALSE && $task_id == FALSE){
			$generated_task_id = $this->input->post('generated_task_id');
			$update_type = $this->input->post('update_type');
			
			//check if the variables are empty or undefined
			if($generated_task_id == "" || $update_type == ""){
			// if the variables are undefined return failed
				echo 'failed';
			}else{
			//if the variables are not empty call the model function for the generated task's status updating
				$result = $this->main_model->update_generated_task_status($generated_task_id, $update_type);
				//check if the updating was successful
				if($result){
				//if the updating return true which means the update was successful
					echo 'success';
				}else{
					echo 'failed';
				}
			}
		}else{
			$generated_task_id = $task_id;
			$update_type = $type;
			
			//check if the variables are empty or undefined
			if($generated_task_id == "" || $update_type == ""){
			// if the variables are undefined return failed
				echo json_encode('failed');
			}else{
			//if the variables are not empty call the model function for the generated task's status updating
				$result = $this->main_model->update_generated_task_status($generated_task_id, $update_type);
				//check if the updating was successful
				if($result){
				//if the updating return true which means the update was successful
					echo json_encode('success');
				}else{
					echo json_encode('failed');
				}
			}
		}
	}
	
	public function view_tasks(){
		$data['title'] = 'View Tasks';
		$data['posts'] = $this->main_model->get_tasks_or_units('type_task');
		$data['body'] = $this->load->view('view_tasks', $data, true);
		$this->load_template($data);
	}
	
	public function view_units(){
		$data['title'] = 'View Units';
		$data['posts'] = $this->main_model->get_tasks_or_units('type_unit');
		$data['body'] = $this->load->view('view_units', $data, true);
		$this->load_template($data);
	}
	
	/*
		Verifies if the current user have the rights to generate tasks.
		Checks if the tasks has already been generated for this url.
	*/
	public function confirm_generate($url){
		//check if the current user is the creator of the current team
		//before allowing him to generate tasks for this team.
		$current_user_id = $this->session->userdata('user_id');
		$current_team_author_id = $this->session->userdata('current_team_author_id');
		if($current_user_id == $current_team_author_id){
			//If the current user is the creator of the current team proceed with the generation of tasks.
			//Check if this current url already have tasks generated for it.
			$task_status = $this->main_model->get_post($url);
			$task_status = $task_status['labels'];
			if(strpos($task_status, 'task_status_generated') === false){
			//If no task generation has been done.
				//Proceed to the generation of tasks.
				$generate_tasks_results = $this->main_model->generate_tasks($url);
				
				//check if the generation was successful.
				if($generate_tasks_results['result'] == true){
				//if the generation was successful
					$id = $generate_tasks_results['generated_tasks_id'];
					//redirect the user to the newly generated tasks page
					redirect(base_url().'view_generated_tasks/'.$id);
				}else{
				//if the generation failed
					echo json_encode($generate_tasks_results);
				}
			}else{
			//If a task list has already been generated for this url.
				$data['system_message'] =  'A task list has already been generated!';
				echo json_encode($data);
			}
		}else{
		//If the current user's id does not match the current team's creator/author id
		//abort the task generation.
			$data['system_message'] = 'Not allowed because you are not the creator of this team.';
			echo json_encode($data);
		}
	}
	
	public function view_generated_tasks($tasks_id){
		$title = $this->main_model->get_where('id', $tasks_id);
		$data['title'] = $title[0]['title'];
		$data['posts'] = $this->main_model->get_generated_tasks('tasks_id', $tasks_id);
		$data['body'] = $this->load->view('view_generated_tasks', $data, true);
		$this->load_template($data);
	}
	
	//===============================================================================
	//==========================	ANGULAR JS FUNCTIONS	============================
	//===============================================================================
	
	public function angular_getDashboard(){
		$this->load->view('angular/dashboard');
	}
	
	//20170118
	/*
		Returns objects tasks to the browser.
	*/
	public function angular_get($slug){
		$to_get = "type_".$slug;
		if($to_get == "type_team"){
			$data = $this->main_model->get_tasks_or_units($to_get);
		}else{
			//before returning units and tasks into the browser
			//check first if the user has entered into a team
			$current_team_id = $this->session->userdata('current_team_id');
			if(($current_team_id != NULL) || ($current_team_id != FALSE)){
				//echo 'User has entered into a team. Current team id:'.$current_team_id;
				$team_id = $this->session->userdata('current_team_id');
			}else{
				$team_id = NULL;
			}
			$data = $this->main_model->get_team_tasks_or_units($to_get, $team_id, $to_get);
		}
		
		echo json_encode($data);
	}
	
	public function angular_get_generated_tasks($slug){
		$data = $this->main_model->get_generated_tasks('tasks_id', $slug);
		echo json_encode($data);
	}
	
	//20170209
	public function angular_request_join_team($team_id, $team_creator_id){
		//check if the parameters has been set
		if((!$team_id) || (!$team_creator_id)){
			$data['system_message'] = 'Team ID ang Team Creator undefined!';
		}else{
			$current_user_id = $this->session->userdata('user_id');
			//add a request record into the team_relations table
			$result = $this->main_model->team_relations(0, $team_creator_id, $team_id, $current_user_id);
			if($result['result']){
				$data['system_message'] = $result['system_message'].' Success: Join request sent.';
			}else{
				$data['system_message'] = $result['system_message'].' Failed: Join request not sent.';
			}
		}
		
		echo json_encode($data);
	}
	
	//20170209
	public function angular_approve_team_join_request($team_id, $join_requestor_id){
		$current_user_id = $this->session->userdata('user_id');
		$result = $this->main_model->team_relations(2, $current_user_id, $team_id, $join_requestor_id);
		if($result['result']){
			$data['system_message'] = $result['system_message'].' Success: User has been approved.';
		}else{
			$data['system_message'] = $result['system_message'].' Failed: Failed to accept user.';
		}
		echo json_encode($data);
	}
	
	//20170209
	public function angular_get_team_relations($team_id = FALSE){
		$current_user_id = $this->session->userdata('user_id');
		if($team_id != FALSE){
			$result = $this->main_model->team_relations(1, $current_user_id, $team_id, $current_user_id);
			$data['team_relations'] = $result['records'];
			$data['system_message'] = 'Team relations found.';
		}else{
			$data['system_message'] = 'Error: Team ID undefined.';
		}
		echo json_encode($data);
	}
	
	//20170204 enter team
	public function angular_enter_team($team_id, $team_url){
		//check if the current user is allowed or is a member of the requested team
		//if the user is an admin type user allow him to proceed
		
		//check if the current user is an admin type user
		$current_user_user_type = $this->session->userdata('user_type');
		if($current_user_user_type != 'admin'){
			//check if the current user is the author or creator of the team
			//if the current user is the author or creator of the team
			//give him access
			
			//get the author_id of the current team
			$team_details = $this->main_model->get_post($team_url);
			$current_team_creator_id = $team_details['author_id'];
			
			//get the id of the current user from the sessions variables
			$current_user_id = $this->session->userdata('user_id');
			
			//compare the current team's creator id to the current user's id
			if($current_user_id != $current_team_creator_id){
				//check if the current user is a allowed to access the team he is trying to access
				//get the id of the current user from the sessions variables
				$current_user_id = $this->session->userdata('user_id');
				$result = $this->main_model->check_user_team_status($current_user_id, $team_id);
				
				if(!$result['result']){
					$data['system_message'] = 'You are not yet a member of this team.';
					echo json_encode($data);
					return FALSE;
				}else{
					$data['system_message'] = $result['system_message'].' You are a member of this team.';
				}
			}else{
				$data['system_message'] = 'You are the creator of this team.';
			}
		}else{
			$data['system_message'] = 'Welcome Administrator.';
		}
		
		//get the users, tasks, units of the current team
		$data['units'] = $this->main_model->get_team_tasks_or_units('type_units', $team_id);
		$data['tasks'] = $this->main_model->get_team_tasks_or_units('type_tasks', $team_id);
		$data['current_team_details'] = $this->main_model->get_post($team_url);
		
		//add the current_team_id, current_team_name into the sessions variable for future use
		$team_name = $data['current_team_details']['title'];
		$team_creator_id = $data['current_team_details']['author_id'];
		//add the current team's name into the session variables
		$this->session->set_userdata('current_team_name', $team_name);
		//add the current team's team id into the session variables
		$this->session->set_userdata('current_team_id', $team_id);
		//add the current team's author id into the session variables
		$this->session->set_userdata('current_team_author_id', $team_creator_id);
		
		//send result to the browser
		echo json_encode($data);
	}
	
	//when the user decides to leave from the entered team
	//simply set the current_team_id and current_team_name to None
	public function angular_leave_team(){
		$this->session->set_userdata('current_team_name', 'None');
		$this->session->set_userdata('current_team_id', NULL);
		$data['system_message'] = 'You have logged out from the team.';
		echo json_encode($data);
	}
	
	public function angular_add_unit(){
		$this->angular_add_check();
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		$new_unit_name = $request->new_unit_name;
		$new_unit_department = $request->new_unit_department;
		
		$result = $this->main_model->add_unit($new_unit_name, $new_unit_department);
		
		if($result['result'] == TRUE){
			$data['add_unit_result'] = TRUE;
		}else{
			$data['add_unit_result'] = FALSE;
		}

		echo json_encode($data);
	}
	
	public function angular_add_check(){
		//If the user is not entered in a team and is not the creator of the entered team,
		//prevent him from adding tasks and units.
		$current_team_id = $this->session->userdata('current_team_id');
		if($current_team_id != NULL){
			//check if the user is the creator of the current team
			$current_team_creator_id = $this->session->userdata('current_team_author_id');
			$current_user_id = $this->session->userdata('user_id');
			if($current_team_creator_id == $current_user_id){
				return;
			}else{
				$data['system_message'] = 'Failed: You are not the creator of this team.';
				echo json_encode($data);
				exit;
			}
		}else{
			$data['system_message'] = 'Failed: You are not in a team.';
			echo json_encode($data);
			exit;
		}
	}
	
	public function angular_add_task(){
		$this->angular_add_check();
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		$new_task_name = $request->new_task_name;
		$new_task_department = $request->new_task_department;
		
		$result = $this->main_model->add_task($new_task_name, $new_task_department);
		
		if($result['result'] == TRUE){
			$data['add_task_result'] = TRUE;
		}else{
			$data['add_task_result'] = FALSE;
		}

		echo json_encode($data);
	}
	
	//20170203
	//add team
	public function angular_add_team(){
		//retrieve, decode the post method values passed by the browser
		//and store it as an object 
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		$new_team_name = $request->new_team_name;
		
		$result = $this->main_model->add_team($new_team_name);
		
		if($result['result'] == TRUE){
			$data['add_team_result'] = TRUE;
		}else{
			$data['add_team_result'] = FALSE;
		}
		
		echo json_encode($data);
	}
	
	//add a user
	public function angular_add_user(){
		//check if the user is an admin type user, before proceeding
		$this->angular_admin_check();
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		$new_user_name = $request->new_user_name;
		$new_user_password = $request->new_user_password;
		
		$angular_variables->new_name = $new_user_name;
		$angular_variables->new_username = $new_user_name;
		$angular_variables->new_password = $new_user_password;
		$angular_variables->new_email = 'none@none.com';
		
		$result = $this->main_model->register($angular_variables);
		
		if($result['result'] == TRUE){
			$data['add_user_result'] = TRUE;
		}else{
			$data['add_user_result'] = FALSE;
		}

		echo json_encode($data);
	}
	
	//delete user
	public function angular_delete_user($user_id){
		//check if the user is an admin type user, before proceeding
		$this->angular_admin_check();
		$result = $this->main_model->delete_user($user_id);
		
		if($result['result']){
			//if the delete user returned TRUE
			echo json_encode('User deleted.');
		}else{
			echo json_encode('User delete failed.');
		}
	}
	
	//20170202
	//Returns all the registered users in JSON format.
	public function angular_get_users(){
		$users = $this->main_model->get_users();
		echo json_encode($users);
	}
	
	//20170202
	public function angular_get_user_detail($field){
		$result = $this->main_model->get_user_detail($field);
		if($result['result']){
			$data[$field] = $result[$field];
		}else{
			$data[$field] = 'N/A';
		}
		echo json_encode($data);
	}
	
	//20170205
	public function angular_get_current_details(){
		$data['current_team_name'] = $this->session->userdata('current_team_name');
		$data['current_team_id'] = $this->session->userdata('current_team_id');
		echo json_encode($data);
	}
	
	//20170202
	//Check if the user is an administrator type.
	public function angular_admin_check(){
		if($this->session->userdata('user_type') == 'admin'){
			//if the user is an admin type user continue
			return;
		}else{
			//stop executing the script
			echo json_encode('Not allowed.');
			exit;
		}
	}
}